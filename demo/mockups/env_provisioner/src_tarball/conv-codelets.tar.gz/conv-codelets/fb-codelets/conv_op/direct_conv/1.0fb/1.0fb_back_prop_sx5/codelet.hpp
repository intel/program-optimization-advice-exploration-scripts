#if defined(_OPENMP)
# include <omp.h>
#endif

#define VEC_LENGTH 16 /* Assuming max 512 bit SIMD length */

#define LARGE_SIZE 1
#define CONST_DECL 0

/*
#if LARGE_SIZE
// define B in main; others are constant
//#define B 128 //other choices: 1, 4, 8, 16, 32, 64, 256
#define H 7      // other choices: 14, 28, 56, 112, 224
#define W 7      // other choices: 14, 28, 56, 112, 224
#define R_CI 32 // other choices: 32, 64, 256
#define MH 4     // other choices: 8, 16, 32
#define MW 4     // other choices: 8, 16, 32
#define R_CO 32 // other choices: 32, 64, 256
#define R_KH 3   // other choices: 1, 7
#define R_KW 3   // other choices: 1, 7
#define R_K 4    // other choices: 8

#else // SMALL_SIZE is 64 smaller than LARGE_SIZE

#define B 16    // other choices: 1, 4, 8, 16, 32, 64, 256
#define H 7     // other choices: 14, 28, 56, 112, 224
#define W 7     // other choices: 14, 28, 56, 112, 224
#define R_CI 64 // other choices: 32, 64, 256
#define MH 4    // other choices: 8, 16, 32
#define MW 4    // other choices: 8, 16, 32
#define R_CO 64 // other choices: 32, 64, 256
#define R_KH 3  // other choices: 1, 7
#define R_KW 3  // other choices: 1, 7
#define R_K 4   // other choices: 8

#endif
*/

#if CONST_DECL
// int votes[B][H][W][R_CO][MH][MW];
typedef float votes_T /*[B]*/[H][W][R_CO][MH][MW];

// int poses[B][H*2+R_KH-2][W*2+R_KW-2][R_CI][MH][R_K];
// Fixed the padding on H and W
typedef float poses_T /*[B]*/[(H - 1) * 2 + R_KH][(W - 1) * 2 + R_KW][R_CI]
                             [MH][R_K];

// int weights[R_CI][R_CO][R_KH][R_KW][R_K][MW];
typedef float weights_T /*[R_CI]*/[R_CO][R_KH][R_KW][R_K][MW];
#else
typedef float votes_T /*[B]*/;
typedef float poses_T /*[B]*/;
typedef float weights_T /*[R_CI]*/;
#endif



void kernel_large(int B, int H, int W, int R_CI, int MH, int MW, int R_CO, int R_KH, int R_KW, int R_K, votes_T *votes, weights_T *weights, poses_T *poses) ;

void kernel_small(int B, int H, int W, int R_CI, int MH, int MW, int R_CO, int R_KH, int R_KW, int R_K, votes_T *votes, weights_T *weights, poses_T *poses) ;

void kernel_general(int B, int H, int W, int R_CI, int MH, int MW, int R_CO, int R_KH, int R_KW, int R_K, votes_T *votes, weights_T *weights, poses_T *poses) ;
