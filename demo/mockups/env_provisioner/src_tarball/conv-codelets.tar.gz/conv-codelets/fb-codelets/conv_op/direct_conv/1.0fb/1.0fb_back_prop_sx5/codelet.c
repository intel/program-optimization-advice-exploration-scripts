/*
Capsule Network pseudo code

+ : reduction operation
* : combination operation
! : initialize, ignore initial value of votes

def conv_capsule(float(B, H, W, CI, MH, MW) poses,
float(CI, CO, KH, KW, MH, MW) weights)
-> (votes) {
votes(b, h, w, co, m, n) +=!
poses(b, h*2 + r_kh, w*2 + r_kw, r_ci, m, r_k) *
weights(r_ci, co, r_kh, r_kw, r_k, n) where r_k in 0:4
}
*/

/* The code below implement the pseudo code above,
the only difference is that it maps h to H, and w to W, not h*2+r_kh to H, and
w*2+r_kw to W) */

//#include <cctype>
//#include <iomanip>
//#include <iostream>
//#include <random>
#include <stdio.h>
#include <stdlib.h>
//#include <chrono>
#include <string.h>

#include <omp.h>
#include "codelet.hpp"

// define B in main; others are constant
//#define B 128 //other choices: 1, 4, 8, 16, 32, 64, 256
#define B_LARGE 128    // other choices: 1, 4, 8, 16, 32, 64, 256
#define H_LARGE 7      // other choices: 14, 28, 56, 112, 224
#define W_LARGE 7      // other choices: 14, 28, 56, 112, 224
#define R_CI_LARGE 32 // other choices: 32, 64, 256
#define MH_LARGE 4     // other choices: 8, 16, 32
#define MW_LARGE 4     // other choices: 8, 16, 32
#define R_CO_LARGE 32 // other choices: 32, 64, 256
#define R_KH_LARGE 3   // other choices: 1, 7
#define R_KW_LARGE 3   // other choices: 1, 7
#define R_K_LARGE 4    // other choices: 8


#define B_SMALL 16    // other choices: 1, 4, 8, 16, 32, 64, 256
#define H_SMALL 7     // other choices: 14, 28, 56, 112, 224
#define W_SMALL 7     // other choices: 14, 28, 56, 112, 224
#define R_CI_SMALL 64 // other choices: 32, 64, 256
#define MH_SMALL 4    // other choices: 8, 16, 32
#define MW_SMALL 4    // other choices: 8, 16, 32
#define R_CO_SMALL 64 // other choices: 32, 64, 256
#define R_KH_SMALL 3  // other choices: 1, 7
#define R_KW_SMALL 3  // other choices: 1, 7
#define R_K_SMALL 4   // other choices: 8


typedef float weights_large_TM /*[R_CI]*/[R_CO_LARGE][R_KH_LARGE][R_KW_LARGE][R_K_LARGE][MW_LARGE];
typedef float votes_large_TM /*[B]*/[H_LARGE][W_LARGE][R_CO_LARGE][MH_LARGE][MW_LARGE];
typedef float poses_large_TM /*[B]*/[(H_LARGE - 1) * 2 + R_KH_LARGE][(W_LARGE - 1) * 2 + R_KW_LARGE][R_CI_LARGE][MH_LARGE][R_K_LARGE];

typedef float weights_small_TM /*[R_CI]*/[R_CO_SMALL][R_KH_SMALL][R_KW_SMALL][R_K_SMALL][MW_SMALL];
typedef float votes_small_TM /*[B]*/[H_SMALL][W_SMALL][R_CO_SMALL][MH_SMALL][MW_SMALL];
typedef float poses_small_TM /*[B]*/[(H_SMALL - 1) * 2 + R_KH_SMALL][(W_SMALL - 1) * 2 + R_KW_SMALL][R_CI_SMALL][MH_SMALL][R_K_LARGE];

void calc_capsule_simple_large(votes_large_TM* votes, weights_large_TM* weights, poses_large_TM* poses) {
//void calc_capsule_simple(const int B, float votes[B][B][B][B][B][B], float weights[B][B][B][B][B][B], float poses[B][B][B][B][B][B]) {
  int B=B_LARGE, H = H_LARGE, W = W_LARGE, R_CI = R_CI_LARGE, MH = MH_LARGE, MW = MW_LARGE, R_CO=R_CO_LARGE, R_KH=R_KH_LARGE, R_KW=R_KW_LARGE, R_K=R_K_LARGE;
  for (int b = 0; b < B; b++) {
    for (int h = 0;  h < H; h++) {
      for (int w = 0; w < W; w++) {
        for (int r_co = 0; r_co < R_CO; r_co++) {
          for (int mh = 0; mh < MH; mh++) {
            for (int mw = 0; mw < MW; mw++) {
              float sum =  0.0f;;
              for (int r_ci = 0; r_ci < R_CI ; r_ci++) {
                for (int r_kh = 0; r_kh < R_KH; r_kh++) {
                  for (int r_kw = 0; r_kw < R_KW; r_kw++) {
                    for (int r_k = 0; r_k < R_K; r_k++) {
                      sum += poses[b][h * 2 + r_kh][w * 2 + r_kw][r_ci][mh][r_k] * weights[r_ci][r_co][r_kh][r_kw][r_k][mw];
                    }
                  }
                }
              }
              votes[b][h][w][r_co][mh][mw] = sum;
            }
          }
        }
      }
    }
  }
}
void calc_capsule_simple_small(votes_small_TM* votes, weights_small_TM* weights, poses_small_TM* poses) {
//void calc_capsule_simple(const int B, float votes[B][B][B][B][B][B], float weights[B][B][B][B][B][B], float poses[B][B][B][B][B][B]) {
  int B=B_SMALL, H = H_SMALL, W = W_SMALL, R_CI = R_CI_SMALL, MH = MH_SMALL, MW = MW_SMALL, R_CO=R_CO_SMALL, R_KH=R_KH_SMALL, R_KW=R_KW_SMALL, R_K=R_K_SMALL;
  for (int b = 0; b < B; b++) {
    for (int h = 0;  h < H; h++) {
      for (int w = 0; w < W; w++) {
        for (int r_co = 0; r_co < R_CO; r_co++) {
          for (int mh = 0; mh < MH; mh++) {
            for (int mw = 0; mw < MW; mw++) {
              float sum =  0.0f;;
              for (int r_ci = 0; r_ci < R_CI ; r_ci++) {
                for (int r_kh = 0; r_kh < R_KH; r_kh++) {
                  for (int r_kw = 0; r_kw < R_KW; r_kw++) {
                    for (int r_k = 0; r_k < R_K; r_k++) {
                      sum += poses[b][h * 2 + r_kh][w * 2 + r_kw][r_ci][mh][r_k] * weights[r_ci][r_co][r_kh][r_kw][r_k][mw];
                    }
                  }
                }
              }
              votes[b][h][w][r_co][mh][mw] = sum;
            }
          }
        }
      }
    }
  }
}
// typedef float votes_large_T /*[B]*/[H][W][R_CO][MH][MW];

// // int poses[B][H*2+R_KH-2][W*2+R_KW-2][R_CI][MH][R_K];
// // Fixed the padding on H and W
// typedef float poses_large_T /*[B]*/[(H - 1) * 2 + R_KH][(W - 1) * 2 + R_KW][R_CI]
//                              [MH][R_K];

// // int weights[R_CI][R_CO][R_KH][R_KW][R_K][MW];
// typedef float weights_large_T /*[R_CI]*/[R_CO][R_KH][R_KW][R_K][MW];
void kernel_large(int B, int H, int W, int R_CI, int MH, int MW, int R_CO, int R_KH, int R_KW, int R_K, votes_T *votes, weights_T *weights, poses_T *poses) {
  //B = 128; H = 7; W = 7; R_CI = 32; MH = 4; MW = 4; R_CO=32; R_KH=3; R_KW=3; R_K=4;
  calc_capsule_simple_large((votes_large_TM*)votes, (weights_large_TM*)weights, (poses_large_TM*)poses);
}
void kernel_small(int B, int H, int W, int R_CI, int MH, int MW, int R_CO, int R_KH, int R_KW, int R_K, votes_T *votes, weights_T *weights, poses_T *poses) {
  //B = 128; H = 7; W = 7; R_CI = 32; MH = 4; MW = 4; R_CO=32; R_KH=3; R_KW=3; R_K=4;
  calc_capsule_simple_small((votes_small_TM*)votes, (weights_small_TM*)weights, (poses_small_TM*)poses);
}

void kernel_large_flattened(int B, int H, int W, int R_CI, int MH, int MW, int R_CO, int R_KH, int R_KW, int R_K, votes_T *votes, weights_T *weights, poses_T *poses) {
  B = 128; H = 7; W = 7; R_CI = 32; MH = 4; MW = 4; R_CO=32; R_KH=3; R_KW=3; R_K=4;

  // typedef float poses_T /*[B]*/[(H - 1) * 2 + R_KH][(W - 1) * 2 + R_KW][R_CI]
  //                        [MH][R_K];
  // so for poses[b][h * 2 + r_kh][w * 2 + r_kw][r_ci][mh][r_k],  we have the following strides
  int poses_mh_stride = R_K;
  int poses_r_ci_stride = MH * poses_mh_stride;
  int poses_w2_r_kw_stride = R_CI * poses_r_ci_stride;
  int poses_h2_r_kh_stride = ((W - 1) * 2 + R_KW) * poses_w2_r_kw_stride;
  int poses_b_stride = ((H - 1) * 2 + R_KH) * poses_h2_r_kh_stride;

  // typedef float weights_T /*[R_CI]*/[R_CO][R_KH][R_KW][R_K][MW];
  // so for weights[r_ci][r_co][r_kh][r_kw][r_k][mw] we have the following strides
  int weights_r_k_stride = MW;
  int weights_r_kw_stride = R_K*weights_r_k_stride;
  int weights_r_kh_stride = R_KW*weights_r_kw_stride;
  int weights_r_co_stride = R_KH*weights_r_kh_stride;
  int weights_r_ci_stride = R_CO*weights_r_co_stride;

  // typedef float votes_T /*[B]*/[H][W][R_CO][MH][MW];
  // so for votes[b][h][w][r_co][mh][mw] we have the following strides
  int votes_mh_stride = MW;
  int votes_r_co_stride = MH*votes_mh_stride;
  int votes_w_stride = R_CO*votes_r_co_stride;
  int votes_h_stride = W*votes_w_stride;
  int votes_b_stride = H*votes_h_stride;
#pragma @ICE loop=capsuleFilterLarge
    for (int b = 0; b < B; b++) {
      for (int h = 0;  h < H; h++) {
        for (int w = 0; w < W; w++) {
          for (int r_co = 0; r_co < R_CO; r_co++) {
            for (int mh = 0; mh < MH; mh++) {
              for (int mw = 0; mw < MW; mw++) {
                float sum =  0.0f;;
                for (int r_ci = 0; r_ci < R_CI ; r_ci++) {
                  for (int r_kh = 0; r_kh < R_KH; r_kh++) {
                    for (int r_kw = 0; r_kw < R_KW; r_kw++) {
                      for (int r_k = 0; r_k < R_K; r_k++) {
                        //sum += poses[b][h * 2 + r_kh][w * 2 + r_kw][r_ci][mh][r_k] * 
                        sum += poses[b*poses_b_stride + (h * 2 + r_kh)*poses_h2_r_kh_stride + (w * 2 + r_kw)*poses_w2_r_kw_stride + r_ci*poses_r_ci_stride + mh*poses_mh_stride + r_k] * 
                          //weights[r_ci][r_co][r_kh][r_kw][r_k][mw];
                          weights[r_ci*weights_r_ci_stride + r_co*weights_r_co_stride + r_kh*weights_r_kh_stride + r_kw*weights_r_kw_stride + r_k*weights_r_k_stride + mw];
                      }
                    }
                  }
                }
                //votes[b][h][w][r_co][mh][mw] = sum;
                votes[b*votes_b_stride + h*votes_h_stride + w*votes_w_stride + r_co*votes_r_co_stride + mh*votes_mh_stride + mw] = sum;
              }
            }
          }
        }
      }
    }
//#pragma @ICE loop=capsuleFilterLarge
}
void kernel_small_flattened(int B, int H, int W, int R_CI, int MH, int MW, int R_CO, int R_KH, int R_KW, int R_K, votes_T *votes, weights_T *weights, poses_T *poses) {
  B = 16; H = 7; W = 7; R_CI = 64; MH = 4; MW = 4; R_CO=64; R_KH=3; R_KW=3; R_K=4;

  // typedef float poses_T /*[B]*/[(H - 1) * 2 + R_KH][(W - 1) * 2 + R_KW][R_CI]
  //                        [MH][R_K];
  // so for poses[b][h * 2 + r_kh][w * 2 + r_kw][r_ci][mh][r_k],  we have the following strides
  int poses_mh_stride = R_K;
  int poses_r_ci_stride = MH * poses_mh_stride;
  int poses_w2_r_kw_stride = R_CI * poses_r_ci_stride;
  int poses_h2_r_kh_stride = ((W - 1) * 2 + R_KW) * poses_w2_r_kw_stride;
  int poses_b_stride = ((H - 1) * 2 + R_KH) * poses_h2_r_kh_stride;

  // typedef float weights_T /*[R_CI]*/[R_CO][R_KH][R_KW][R_K][MW];
  // so for weights[r_ci][r_co][r_kh][r_kw][r_k][mw] we have the following strides
  int weights_r_k_stride = MW;
  int weights_r_kw_stride = R_K*weights_r_k_stride;
  int weights_r_kh_stride = R_KW*weights_r_kw_stride;
  int weights_r_co_stride = R_KH*weights_r_kh_stride;
  int weights_r_ci_stride = R_CO*weights_r_co_stride;

  // typedef float votes_T /*[B]*/[H][W][R_CO][MH][MW];
  // so for votes[b][h][w][r_co][mh][mw] we have the following strides
  int votes_mh_stride = MW;
  int votes_r_co_stride = MH*votes_mh_stride;
  int votes_w_stride = R_CO*votes_r_co_stride;
  int votes_h_stride = W*votes_w_stride;
  int votes_b_stride = H*votes_h_stride;
    #pragma @ICE loop=capsuleFilterSmall
    for (int b = 0; b < B; b++) {
      for (int h = 0;  h < H; h++) {
        for (int w = 0; w < W; w++) {
          for (int r_co = 0; r_co < R_CO; r_co++) {
            for (int mh = 0; mh < MH; mh++) {
              for (int mw = 0; mw < MW; mw++) {
                float sum =  0.0f;;
                for (int r_ci = 0; r_ci < R_CI ; r_ci++) {
                  for (int r_kh = 0; r_kh < R_KH; r_kh++) {
                    for (int r_kw = 0; r_kw < R_KW; r_kw++) {
                      for (int r_k = 0; r_k < R_K; r_k++) {
                        //sum += poses[b][h * 2 + r_kh][w * 2 + r_kw][r_ci][mh][r_k] * 
                        sum += poses[b*poses_b_stride + (h * 2 + r_kh)*poses_h2_r_kh_stride + (w * 2 + r_kw)*poses_w2_r_kw_stride + r_ci*poses_r_ci_stride + mh*poses_mh_stride + r_k] * 
                          //weights[r_ci][r_co][r_kh][r_kw][r_k][mw];
                          weights[r_ci*weights_r_ci_stride + r_co*weights_r_co_stride + r_kh*weights_r_kh_stride + r_kw*weights_r_kw_stride + r_k*weights_r_k_stride + mw];
                      }
                    }
                  }
                }
                //votes[b][h][w][r_co][mh][mw] = sum;
                votes[b*votes_b_stride + h*votes_h_stride + w*votes_w_stride + r_co*votes_r_co_stride + mh*votes_mh_stride + mw] = sum;
              }
            }
          }
        }
      }
    }
}
void kernel_general(int B, int H, int W, int R_CI, int MH, int MW, int R_CO, int R_KH, int R_KW, int R_K, votes_T *votes, weights_T *weights, poses_T *poses) {

  // typedef float poses_T /*[B]*/[(H - 1) * 2 + R_KH][(W - 1) * 2 + R_KW][R_CI]
  //                        [MH][R_K];
  // so for poses[b][h * 2 + r_kh][w * 2 + r_kw][r_ci][mh][r_k],  we have the following strides
  int poses_mh_stride = R_K;
  int poses_r_ci_stride = MH * poses_mh_stride;
  int poses_w2_r_kw_stride = R_CI * poses_r_ci_stride;
  int poses_h2_r_kh_stride = ((W - 1) * 2 + R_KW) * poses_w2_r_kw_stride;
  int poses_b_stride = ((H - 1) * 2 + R_KH) * poses_h2_r_kh_stride;

  // typedef float weights_T /*[R_CI]*/[R_CO][R_KH][R_KW][R_K][MW];
  // so for weights[r_ci][r_co][r_kh][r_kw][r_k][mw] we have the following strides
  int weights_r_k_stride = MW;
  int weights_r_kw_stride = R_K*weights_r_k_stride;
  int weights_r_kh_stride = R_KW*weights_r_kw_stride;
  int weights_r_co_stride = R_KH*weights_r_kh_stride;
  int weights_r_ci_stride = R_CO*weights_r_co_stride;

  // typedef float votes_T /*[B]*/[H][W][R_CO][MH][MW];
  // so for votes[b][h][w][r_co][mh][mw] we have the following strides
  int votes_mh_stride = MW;
  int votes_r_co_stride = MH*votes_mh_stride;
  int votes_w_stride = R_CO*votes_r_co_stride;
  int votes_h_stride = W*votes_w_stride;
  int votes_b_stride = H*votes_h_stride;
    #pragma @ICE loop=capsuleFilterGeneral
    for (int b = 0; b < B; b++) {
      for (int h = 0;  h < H; h++) {
        for (int w = 0; w < W; w++) {
          for (int r_co = 0; r_co < R_CO; r_co++) {
            for (int mh = 0; mh < MH; mh++) {
              for (int mw = 0; mw < MW; mw++) {
                float sum =  0.0f;;
                for (int r_ci = 0; r_ci < R_CI ; r_ci++) {
                  for (int r_kh = 0; r_kh < R_KH; r_kh++) {
                    for (int r_kw = 0; r_kw < R_KW; r_kw++) {
                      for (int r_k = 0; r_k < R_K; r_k++) {
                        //sum += poses[b][h * 2 + r_kh][w * 2 + r_kw][r_ci][mh][r_k] * 
                        sum += poses[b*poses_b_stride + (h * 2 + r_kh)*poses_h2_r_kh_stride + (w * 2 + r_kw)*poses_w2_r_kw_stride + r_ci*poses_r_ci_stride + mh*poses_mh_stride + r_k] * 
                          //weights[r_ci][r_co][r_kh][r_kw][r_k][mw];
                          weights[r_ci*weights_r_ci_stride + r_co*weights_r_co_stride + r_kh*weights_r_kh_stride + r_kw*weights_r_kw_stride + r_k*weights_r_k_stride + mw];
                      }
                    }
                  }
                }
                //votes[b][h][w][r_co][mh][mw] = sum;
                votes[b*votes_b_stride + h*votes_h_stride + w*votes_w_stride + r_co*votes_r_co_stride + mh*votes_mh_stride + mw] = sum;
              }
            }
          }
        }
      }
    }
}

//void calc_capsule_simple(const int B, votes_T *votes, weights_T *weights, poses_T *poses) {
//void calc_capsule_simple(const Param& read_param, votes_T *votes, weights_T *weights, poses_T *poses) {