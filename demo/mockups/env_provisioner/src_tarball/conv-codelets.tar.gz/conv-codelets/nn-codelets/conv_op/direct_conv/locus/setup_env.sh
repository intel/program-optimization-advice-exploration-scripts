#!/usr/bin/env bash

pipspath=~/MYPIPSpy3

#. /opt/intel/bin/compilervars.sh intel64
. ${pipspath}/pipsrc.sh

export LD_LIBRARY_PATH=/home/tteixei2/naive_conv/nn-codelets/codeletProbe:$LD_LIBRARY_PATH

# Necessary for Pips when using gcc 7 or 8
#export PIPS_CPP="gcc -std=c99 -E -C -ffreestanding"
#export PIPS_CC="gcc -std=c99 -ffreestanding -c -o /dev/null"
