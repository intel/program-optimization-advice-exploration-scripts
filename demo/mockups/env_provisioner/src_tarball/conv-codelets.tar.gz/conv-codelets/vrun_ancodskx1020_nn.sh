#!/bin/bash -l

#source ../cls/base/const.sh
#source ../cls/base/vrun_launcher.sh
source ../../cls/base/const.sh
source ../../cls/base/vrun_launcher.sh

#PUT compiler source stuff here
#source ${COMPILER_ROOT}/compilers/intel/16.0/Linux/intel64/load0.sh
#source /opt/intel/compilers_and_libraries_2018/linux/bin/compilervars.sh -arch intel64 -platform linux
#source /nfs/site/proj/openmp/compilers/intel/18.0/Linux/intel64/load0.sh 

#declare -ga all_layers
export all_layers=$(cat nn-codelets/GoogleNet_V1_full.txt)


parameter_set_decoding () {
  codelet=$1
  datasize=$2
  repetition=$3
  rundir=$4
 
  layer_array=( $all_layers )
#echo ${all_layers[*]} >> /tmp/ds.txt
# Create the datasize file for codelet run
  if [[ $datasize =~ ^[0-9]+$ ]]; then
    # number - layer
    layer_num=$datasize
    # Bash array starts from 0
    (( datasize -- ))
    datasize=${layer_array[$datasize]}
  else
    # not a number - use the exact string, fall through
    layer_num=-1
  fi
  echo "${repetition} ${datasize}" > ./codelet.data

  echo "Layer,Image Height,Image Width,Number of images,Input Channel,Output Channel,Filter Height,Filter Width,Padding,Padding1,Stride" > arguments.csv
  echo "${layer_num},${datasize}"|sed 's/:/,/g' >> arguments.csv
  echo ""
}

build_codelet () {
  codelet_folder="$1"
  codelet_name="$2"
  build_folder="$3"

  # Simple codelet compilation
  binary_name=$( grep "binary name" "$codelet_folder/codelet.conf" | sed -e 's/.*"\(.*\)".*/\1/g' )
  echo -e "Binary name \t'$binary_name'"
# ensured it is at the same level as codelet_folder so that relative paths in Makefile is preserved it will be moved to the build_folder 
# after generating original
  build_tmp_folder=$(mktemp -d --tmpdir=${codelet_folder}/..)
  
  
  echo "Generating codelet '$codelet_folder/$codelet_name'..."
  
  echo "Compiler information using -v flags"
  ifort -v
  icc -v
  icpc -v
  
  build_files=$(find ${codelet_folder} -maxdepth 1 -type f -o -type l)
  cp ${build_files} ${build_tmp_folder}
  
  cd ${build_tmp_folder}
  
  if [[ "$ENABLE_SEP" == "1" ]]; then
      make clean ENABLE_SEP=sep ${emon_api_flags} all
  else
      make LIBPATH="${BASE_PROBE_FOLDER}" clean all
  fi
  
  res=$?
  
  if [[ "$res" != "0" ]]; then
      echo "ERROR! Make did not succeed."
      exit -1
  fi
  
  mv "$binary_name" "$codelet_name"
  res=$?
  
  if [[ "$res" != "0" ]]; then
      echo "ERROR! Move did not succeed."
      exit -1
  fi
  
  
  if [[ -e "codelet.o" ]]; then
      cp "codelet.o" "$codelet_folder/$CLS_RES_FOLDER/"	
  fi
  
# Should be safe because $binary_name was already renamed to $codelet_name
  make clean &> /dev/null
  
  echo "Codelet generation was successful."
  mv ${build_tmp_folder} "${build_folder}"
}

export -f parameter_set_decoding
export -f build_codelet


run() {
    runId=$@

#variants="REF LS FP DL1 NOLS-NOFP FP_SAN REF_SAN FES LS_FES FP_FES"
variants="REF LS FP DL1 FES"
#variants="REF LS FP"
#variants="REF"
variants="ORG"
#variants="REF_SAN"
#variants="FP"
#variants="LS"
#linear_sizes="2000 10000000"
#linear_sizes="1000 2000"

#linear_sizes="1000 2000 4000 6000 8000 10000 20000 40000 60000 80000 100000 200000 400000 600000 800000 1000000 2000000 4000000 6000000 8000000 10000000"

#linear_sizes="2000 8000 80000 200000 600000 1000000"
#linear_sizes="2000 10000 400000 8000000"
#linear_sizes="2000 8000 400000"
# Even small datasizes for LDA code (like svd11)
#linear_sizes="600 800 1000"
#linear_sizes="1000"
#linear_sizes="400 2000 10000"
#linear_clda_sizes="1000 10000"
linear_clda_sizes="1000"
#ubmk_sizes="400 2000 10000 800000"
#ubmk_sizes="10000 800000"
#ubmk_sizes="800000"
#ubmk_sizes="100 200 400 600 800 1000 2000 4000 6000 8000 10000 20000 40000 60000 80000 100000 200000"
#ubmk_sizes="600 1000"
#ubmk_sizes="200 1000 10000"
#ubmk_sizes="10000"
ubmk_sizes="100000 200000"

#linear_sizes="400000"
#linear_sizes="200000 400000 600000 800000"
#linear_sizes="2000 10000"
#linear_sizes="1000 10000"
#linear_sizes="10000"
# Will check size problem below for hqr13 and toe3
#linear_sizes="100 1000 10000 400000"
#linear_sizes="3000 4000 5000"
#linear_sizes="1000 10000 400000"


#linear_sizes="800000"
#linear_sizes="100 200 400 600 800"
#linear_sizes="1100 1200 1400 1600 1800"
#linear_sizes="1000000 2000000 4000000 6000000 8000000 10000000"
#linear_sizes="1000000 4000000 8000000 10000000"
#linear_sizes="1000 2000 4000 8000 20000  60000 100000  400000 800000 1000000  10000000"
#linear_sizes="100000  400000 800000 1000000  10000000"
#linear_sizes="1000 2000 1000000  10000000"
#linear_sizes="2000 100000 1000000  10000000"
#linear_sizes="208 240 304 352 400 528 608 704 800 928 1008 1100 1200 1300 1400 1500 1600 1800 2000 2500 3000"
# for ubmk branch_de
#linear_sizes="48 104 208 304 328 344 352 360 368 376 384 392 400 432 456 504 600 800 1440 2000 3000 30000"

#linear_sizes="6 13"
#linear_sizes="6 13 26 38 41 43 44 45 46 47 48 49 50 54 57 63 75 100 180 250 375 3750"


#linear_sizes="1000 2000 4000 6000 8000 10000 20000 40000"
linear_sizes="10000"
nn_sizes="4000"



#quadratic_sizes="208 240 304 352 400 528 608 704 800 928 1008 1100 1200 1300 1400 1500 1600 1800 2000 2500 3000"
#quadratic_sizes="800"
#quadratic_sizes="1500 3000 6000"
#quadratic_sizes="208 304 528  1500 3000"
#quadratic_sizes="208 352 608 928 1200 1500 2000 3000"
#quadratic_sizes="208 352 608 928 1300 2500"
#quadratic_sizes="208 240 400 2500 3000"
quadratic_sizes="100"
#quadratic_sizes="928 1008 1100"
#quadratic_sizes="928"
#quadratic_sizes="10 30 100 400 630 928"
#quadratic_sizes="100 400"
# try to follow Hafid's sizes
#quadratic_sizes="100 208 240 352 400 528"
#quadratic_sizes="100"
#quadratic_sizes="10 30 100 400"
#quadratic_sizes="208 400 528"

#quadratic_sizes="400 2500"
#quadratic_sizes="3000"
#memory_loads="0 99999"
memory_loads="0"
#num_cores="2 4 8"
#num_cores="1 2 4 8"
#num_cores="1 8"
#num_cores="2 4"
#num_cores="1 2 8"
#num_cores="1 2"
num_cores="1"
#num_cores="4"
#num_cores="2 4"
prefetchers="0"
#prefetchers="0 15"
#prefetchers="15"
#frequencies="1200000 2800000"
#frequencies="2800000"
#frequencies="3200000"
#frequencies="2000000"
frequencies="2200000"
#frequencies="2200000"
#frequencies="2400000"
#frequencies="1200000 2000000 2800000"
#frequencies="1200000 1300000 1400000 1500000 1700000 1800000 1900000 2000000 2100000 2200000 2300000 2500000 2600000 2700000 2800000"
#frequencies="1200000"

linear_codelets=""
quadratic_codelets=""
ptr_codelets=""


#prefix="/nfs/fx/home/cwong29/working/NR-scripts"
prefix=$(readlink -f ../..)
#ubmkprefix="${prefix}/nr-codelets/bws/nr_ubmks"
ubmkprefix="${prefix}/nr-codelets/bws"
nr_prefix="${prefix}/nr-codelets/numerical_recipes"
saeed_prefix="${prefix}/intel_codelets"   
andy_prefix="${prefix}/andy_codelets/invitro"
galois_prefix="${prefix}/galois_codelets"
nn_prefix="${prefix}/nn-codelets/naive_conv/nn-codelets/conv_op"

lin_s1_prefix="${nr_prefix}/1D_loop-Stride_1"
lin_slda_prefix="${nr_prefix}/1D_loop-Stride_LDA"
lin_sclda_prefix="${nr_prefix}/1D_loop-Stride_CLDA"
quad_s1_prefix="${nr_prefix}/2D_loop-Stride_1"
quad_slda_prefix="${nr_prefix}/2D_loop-Stride_LDA"
quadt_s1_prefix="${nr_prefix}/2DT_loop-Stride_1"
direct_conv_prefix="${nn_prefix}/direct_conv"

saeed_lin_s1_prefix="${saeed_prefix}/1D_loop-Stride_1"
andy_lin_s1_prefix="${andy_prefix}/1D_loop-Stride_1"
andy_quad_s1_prefix="${andy_prefix}/2D_loop-Stride_1"
galois_lonestar_prefix="${galois_prefix}/lonestar"


declare -gA name2path
declare -gA name2sizes
declare -ga run_codelets


# fill_codelet_maps "${lin_s1_prefix}" "${linear_sizes}" "$(IFS=' '; echo ${lin_s1_codelets[@]})"
# fill_codelet_maps "${saeed_lin_s1_prefix}" "${linear_sizes}" "$(IFS=' '; echo ${saeed_lin_s1_codelets[@]})"
# fill_codelet_maps ${lin_slda_prefix} "${linear_sizes}" "$(IFS=' '; echo ${lin_slda_codelets[@]})"
# fill_codelet_maps ${lin_sclda_prefix} "${linear_clda_sizes}" "$(IFS=' '; echo ${lin_sclda_codelets[@]})"
# fill_codelet_maps ${quad_s1_prefix} "${quadratic_sizes}" "$(IFS=' '; echo ${quad_s1_codelets[@]})"
# fill_codelet_maps ${quad_slda_prefix} "${quadratic_sizes}" "$(IFS=' '; echo ${quad_slda_codelets[@]})"
# fill_codelet_maps ${quadt_s1_prefix} "${quadratic_sizes}" "$(IFS=' '; echo ${quadt_s1_codelets[@]})"
# fill_codelet_maps ${ubmkprefix} "${ubmk_sizes}" "$(IFS=' '; echo ${ubmk_codelets[@]})"

#fill_codelet_maps "${lin_s1_prefix}" "${linear_sizes}"
#fill_codelet_maps "${saeed_lin_s1_prefix}" "${linear_sizes}"
#fill_codelet_maps "${andy_lin_s1_prefix}" "${linear_sizes}"
#fill_codelet_maps "${andy_quad_s1_prefix}" "${linear_sizes}"
#fill_codelet_maps "${galois_lonestar_prefix}" "${linear_sizes}"
#fill_codelet_maps ${lin_slda_prefix} "${linear_sizes}"
#fill_codelet_maps ${lin_sclda_prefix} "${linear_clda_sizes}"
#fill_codelet_maps ${quad_s1_prefix} "${quadratic_sizes}"
#fill_codelet_maps ${quad_slda_prefix} "${quadratic_sizes}"
#fill_codelet_maps ${quadt_s1_prefix} "${quadratic_sizes}"
#fill_codelet_maps ${ubmkprefix} "${ubmk_sizes}"
fill_codelet_maps "${direct_conv_prefix}" "${nn_sizes}"


#for ((i=0; i<${#all_layers[*]}; i++)); do
#  layer=${all_layers[$i]}
#  layer_map[${layer}]=$i
#  echo ${layer_map[${layer}]} $layer
#done
#name2sizes[1.0_ufs_back_prop_se]="200:200:8:8:8:100:100:0:0:1"


#name2sizes[back_prop]="56:56:8:64:192:3:3:1:1:1"
#name2sizes[back_prop]="$(cat ../../nn-codelets/GoogleNet_V1.txt)"
#selects=(${name2sizes[back_prop]})
#echo ${selects[24]}
#echo ${selects[0]}
#name2sizes[back_prop]=${selects[24]}
#name2sizes[back_prop]=${selects[0]}

#ds="56:56:8:64:192:3:3:1:1:1"
# below should be 28:28:8:192:64:1:1:0:0:1
dss=($all_layers)
ds=${dss[2]}

name2sizes[1.0_ufs_back_prop_se]=${ds}
name2sizes[1.11_back_prop_sx5]=${ds}
name2sizes[1.2_back_prop_se]=${ds}

for n in 1.0_back_prop_se 1.0_ufs_back_prop_se 1.1_back_prop_sx5 1.11_back_prop_sx5 1.2_back_prop_se 1.2_back_prop_sx5 2.0_back_prop_sx 2.0_back_prop_se 2.0_back_prop_sx2 2.0_back_prop_sx5 2.1_back_prop_sx5 2.2_back_prop_sx5; do
#    name2sizes[${n}]=${ds}
     name2sizes[${n}]=$(seq -s " " 1 48)
#     name2sizes[${n}]=$(seq -s " " 4 5)
done



#name2sizes[1.0_back_prop_se]="11 35 6 13 30 28"
#name2sizes[1.1_back_prop_sx5]="11 35 6 13 30 28"
#name2sizes[1.11_back_prop_sx5]="11 35 6 13 30 28"
#name2sizes[1.0_back_prop_se]="2"
#name2sizes[1.1_back_prop_sx5]="2"
#name2sizes[1.11_back_prop_sx5]="2"
#name2sizes[1.0_back_prop_se]="3"
#name2sizes[1.1_back_prop_sx5]="3"
#name2sizes[1.11_back_prop_sx5]="3"


run_codelets=(
#      1.0_back_prop_se
# #     1.0_ufs_back_prop_se
      1.1_back_prop_sx5
# #     1.11_back_prop_sx5
# ###1.0_back_prop_se          
# ###1.0_ufs_back_prop_se  
# ##1.1_back_prop_sx5    
# ##1.11_back_prop_sx5  
# ##1.2_back_prop_se     
1.2_back_prop_sx5  
# #2.0_back_prop_se   
# #2.0_back_prop_sx   
# 2.0_back_prop_sx2  

2.0_back_prop_sx5

2.1_back_prop_sx5
2.2_back_prop_sx5
)

run_codelets=(
#      1.0_back_prop_se
# #     1.0_ufs_back_prop_se
      1.1_back_prop_sx5
)

#runLoop "${runId}" "$variants" "$memory_loads" "$frequencies"  "$num_cores" "$prefetchers" "RESOURCE=1,SQ=0,SQ_HISTOGRAM=0,LFB_HISTOGRAM=0,TOPDOWN=0,LFB=1,MEM_ROWBUFF=0,MEM_TRAFFIC=1,MEM_HIT=1,TLB=1,LSD=0"
#runLoop "${runId}" "$variants" "$memory_loads" "$frequencies"  "$num_cores" "$prefetchers" "RESOURCE=0,SQ=0,SQ_HISTOGRAM=0,LFB_HISTOGRAM=0,TOPDOWN=0,LFB=0,MEM_ROWBUFF=0,MEM_TRAFFIC=0,MEM_HIT=0,TLB=0,LSD=0"
#runId="${runId}" variants="$variants" memory_loads="$memory_loads" frequencies="$frequencies" unc_frequencies="$frequencies" num_cores="$num_cores" prefetchers="$prefetchers" counter_list_override="RESOURCE=1,SQ=0,SQ_HISTOGRAM=0,LFB_HISTOGRAM=0,TOPDOWN=0,LFB=1,MEM_ROWBUFF=0,MEM_TRAFFIC=1,MEM_HIT=1,TLB=1,LSD=0" runLoop
# Minimal run
runId="${runId}" variants="$variants" memory_loads="$memory_loads" frequencies="$frequencies" unc_frequencies="$unc_frequencies" num_cores="$num_cores" prefetchers="$prefetchers" counter_list_override="RESOURCE=0,SQ=0,SQ_HISTOGRAM=0,LFB_HISTOGRAM=0,TOPDOWN=0,LFB=0,MEM_ROWBUFF=0,MEM_TRAFFIC=0,MEM_HIT=0,TLB=0,LSD=0" runLoop





return

set -o pipefail # make sure pipe of tee would not reset return code.


echo RUN codelets : ${run_codelets[@]}

for codelet in ${run_codelets[@]}
do
  codelet_path=${name2path[${codelet}]}
  sizes=${name2sizes[${codelet}]}
#  echo ${codelet_path}
#  ls ${codelet_path}
#  echo "SS: ${sizes}"

  echo "Launching CLS on $codelet_path...for sizes $sizes"

  ${LOGGER_SH} ${runId} "Launching CLS on '$codelet_path'..."

  ./cls.sh "$codelet_path" "$variants" "${sizes}" "$memory_loads" "$frequencies"  "${runId}" | tee "$codelet_path/cls.log"
  res=$?
  if [[ "$res" != "0" ]]
      then
#      echo -e "\tAn error occured! Check '$codelet_path/cls.log' for more information."
      ${LOGGER_SH} ${runId} "FAILED: Check '${codelet_path}/cls.log' for more information."
  fi
done

}

launchIt $0 run "$@"


