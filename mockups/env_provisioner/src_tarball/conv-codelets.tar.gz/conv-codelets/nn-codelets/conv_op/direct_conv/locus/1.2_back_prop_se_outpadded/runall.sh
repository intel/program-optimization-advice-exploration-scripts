#!/bin/bash

RUN_ONEVIEW_ONLY=0
count=0

ALL_FILES="/tmp/layers.txt /tmp/all-code.txt /tmp/all-variant.txt /tmp/runs.txt /tmp/time.txt"
rm -f $ALL_FILES
touch $ALL_FILES
echo "Layer" > /tmp/layers.txt
echo "Version" > /tmp/all-code.txt
echo "Variant" > /tmp/all-variant.txt
echo "Run" > /tmp/runs.txt
echo "Cycles" > /tmp/time.txt

gcd() (
    ! (( $1 % $2 )) && echo $2 || gcd $2 $(( $1 % $2 ))
)

run_all_versions() {
	layer="$1"
	layer_number="$2"
	echo "100 $layer" > codelet.data
	cp codelet.data ./data
	#echo $layer
	#for exe in ../../*/*VL*sx5/convf32_avx512;
	#for exe in ../../*/*sx5/convf32_avx512;
	#for exe in ../../*/*1.2-T*sx5/convf32_avx512;
	for exe in ../../*/*[0-9]_back*sx5/convf32_avx512;
	do
		version=$(echo $exe | cut -f3 -d/)
		variant=$(echo $exe | cut -f4 -d/|sed 's/_back_prop_sx5//g')

		C_value=$(echo $layer |cut -f4 -d:)
		K_value=$(echo $layer |cut -f5 -d:)
		gcd_value=$(gcd $C_value $K_value)
		#echo $gcd_value
		echo $exe
		#VL_factor=$(echo ../../1.2/1.2-2VL_back_prop_sx5/convf32_avx512 |cut -f1 -dV |cut -f2 -d-)
		if [[ $exe == *VL* ]]; then
			VL_factor=$(echo $exe |cut -f1 -dV |cut -f2 -d-)
		       	echo HERE:$VL_factor 
			VL=$(((VL_factor*16)))
		       	#echo $VL
		       	remainder=$((gcd_value%VL))
		       	if [[ $remainder != 0 ]]; then
			       	continue
		       	fi
		fi
		echo $variant
		echo $variant-$layer

		if [[ $RUN_ONEVIEW_ONLY == 1 ]]; then
			LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:$(readlink -f ../../../../codeletProbe):/host/localdisk/cwong29/working/NR-scripts/cape-experiment-scripts/utils/MAQAO/maqao_new_2020/lib /host/localdisk/cwong29/working/NR-scripts/cape-experiment-scripts/utils/MAQAO/maqao_new_2020/maqao oneview  -R3 --executable=$exe --dataset=./data --dataset-handler=copy -xp=OV3-$layer-$variant
			# Skip the run below
			continue
		fi


		for run in $(seq 1 5); do
			echo "RUNNING: version $version variant $variant for layer $layer_number, Run# $run"
			LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:../../../../codeletProbe numactl --localalloc -C 47 ${exe}
			echo $run >> /tmp/runs.txt
			tail -1 time.out >> /tmp/time.txt
			echo $layer >> /tmp/layers.txt
			echo $version >> /tmp/all-code.txt
			echo $variant >> /tmp/all-variant.txt
		done
	#ls ../../*/*sx5/convf32_avx512 |cut -f3 -d/ >> /tmp/all-code.txt
	done



#	LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:../../../../codeletProbe ./codelet.ice.exe
#	echo locus >> /tmp/all-code.txt
#	tail -1 time.out >> /tmp/time.txt
#	echo $layer >> /tmp/layers.txt
}

start_time=$(date '+%s')
layer_number=0
for layer in $(cat ../../../../GoogleNet_V1_full-unique.txt); do
	(( layer_number++ ))
	run_all_versions $layer $layer_number
done
end_time=$(date '+%s')
elapsed_time=$((${end_time} - ${start_time}))

echo Finished in $elapsed_time seconds

paste $ALL_FILES -d, > /tmp/locus-cnn.csv

cp /tmp/locus-cnn.csv /nfs/site/proj/alac/tmp/locus-cnn-${end_time}.csv
echo Data saved in /nfs/site/proj/alac/tmp/locus-cnn-${end_time}.csv
