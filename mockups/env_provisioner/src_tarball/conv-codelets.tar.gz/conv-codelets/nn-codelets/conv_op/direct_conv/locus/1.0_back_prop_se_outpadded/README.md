# Setup  instructions for running Search

The code here the ouput buffer has also been padded. I have not check for different strides than one.

Install [Locus](https://bitbucket.org/thiagotei/ice-locus-dev)

Add environment vars to use:

* `export ICE_CMPOPTS_PATH=<path to uiuc-compiler-opts install dir>` for using [UIUC Rose transformations](https://bitbucket.org/thiagotei/uiuc-compiler-opts)
* [Pips](https://pips4u.org/)
* Intel compilers

## UIUC sadr machine

Run the following:

```bash
. ../setup-env-sadr.sh
source ~/pyvirtenvs/envpy3.6-ice/bin/activate
./howtorun.sh
```
