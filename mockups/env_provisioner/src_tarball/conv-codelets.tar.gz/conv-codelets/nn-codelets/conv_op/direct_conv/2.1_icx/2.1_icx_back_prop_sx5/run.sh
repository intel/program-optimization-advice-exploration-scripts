icx -g -fpic -Ofast -fno-alias -ansi-alias -qoverride-limits -xCORE-AVX512 -qopt-report=3 -qopt-report-file=zmm.optrpt -qopt-zmm-usage=high -c codelet.c -S -o codelet-zmm.s
icx -DICX -g  -fpic -O3 -fno-alias -ansi-alias -qoverride-limits -fp-model fast=2 -DNDEBUG -D_REENTRANT -xCore-AVX512 -S -c codelet.c -o codelet.s -qopt-report=3 -qopt-report-file=no-zmm.optrpt
