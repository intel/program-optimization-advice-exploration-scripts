#!/usr/bin/env python

import sys, os, shutil

from pyps import *

def findLoopWithLabel(loops, label):
        for l1 in loops:
            if l1.label == label:
                return l1
            else:
                ret = findLoopWithLabel(l1.loops(), label)
                if ret:
                    return ret
        return None


# removing previous output
if os.path.isdir("codelet.database"):
    shutil.rmtree("codelet.database", True)

# RECIPE PREAMBLE (matmul_1000, Matrix_Mult)

ws = workspace("codelet.c" , name="codelet",deleteOnClose=True)
ws.activate("MUST_REGIONS")
ws.activate("RICE_REGIONS_DEPENDENCE_GRAPH")
ws.props.MEMORY_EFFECTS_ONLY=False
ws.props.PRETTYPRINT_DIV_INTRINSICS=False
fct = ws.fun.naive_conv_bp
#fct.display ()

# RECIPE SELECT LOOP(loop0)
fct.flag_loops()
loop1 = findLoopWithLabel(fct.loops(),"l99996")
fct.display()

# RECIPE RECTANGULAR TILING (2,8,8)
#loop1.loop_tiling (LOOP_TILING_MATRIX = "8 0,0 8")
loop1.loop_tiling (LOOP_TILING_MATRIX = "4 0, 0 4")
fct.display ()

ws.close()
