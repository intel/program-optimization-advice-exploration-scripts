/******************************************************************************
 ** Copyright (c) 2016-2017, Intel Corporation                                **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Redistribution and use in source and binary forms, with or without        **
 ** modification, are permitted provided that the following conditions        **
 ** are met:                                                                  **
 ** 1. Redistributions of source code must retain the above copyright         **
 **    notice, this list of conditions and the following disclaimer.          **
 ** 2. Redistributions in binary form must reproduce the above copyright      **
 **    notice, this list of conditions and the following disclaimer in the    **
 **    documentation and/or other materials provided with the distribution.   **
 ** 3. Neither the name of the copyright holder nor the names of its          **
 **    contributors may be used to endorse or promote products derived        **
 **    from this software without specific prior written permission.          **
 **                                                                           **
 ** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       **
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         **
 ** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     **
 ** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      **
 ** HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    **
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  **
 ** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    **
 ** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    **
 ** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      **
 ** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        **
 ** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              **
 ******************************************************************************/
/* Alexander Heinecke, Hans Pabst, Dhiraj Kalamkar,
 Rajkishore Barik (Intel Corp.)
 ******************************************************************************/

/* Modified by Ankush Mandal (Georgia Tech) */

#include "codelet.h"

void naive_conv_bp(naive_conv_t* param, float* input, const float* output, const float* filter)
{
  int nImg      = param->nImg;
  int nIfm      = param->nIfm;
  int nOfm      = param->nOfm;
  int ifhp      = param->ifhp;
  int ifwp      = param->ifwp;
  int ifh       = param->ifh;
  int ifw       = param->ifw;
  int ofh       = param->ofh;
  int ofw       = param->ofw;
  int pad_h     = param->pad_h;
  int pad_w     = param->pad_w;
  int kh        = param->kh;
  int kw        = param->kw;
  int stride_h  = param->stride_h;
  int stride_w  = param->stride_w;
  /* loop counters */
  int img, ofm, ifm, oj, oi, ij, ii, kj, ki, kj_begin, kj_end, ki_begin, ki_end;
  
  /* strides for array index calculation */
  int input_img_stride  = nIfm * ifhp * ifwp;
  int input_ifm_stride  = ifhp * ifwp;
  int output_img_stride = nOfm * ofh * ofw;
  int output_ofm_stride = ofh * ofw;
  int weight_ofm_stride = nIfm * kh * kw;
  int weight_ifm_stride = kh * kw;

  float* input_t        = &input[pad_h * ifwp + pad_w];

  if (kh == 1 && kw == 1)
  {
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii)
#endif
    for (img = 0; img < nImg; ++img) {
      for (ifm = 0; ifm < nIfm; ++ifm) {
        for (ofm = 0; ofm < nOfm; ++ofm) {
          for (oj = 0; oj < ofh; ++oj) {
            ij = oj * stride_h - pad_h;
            for (oi = 0; oi < ofw; ++oi) {
              ii = oi * stride_w - pad_w;
              input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp) + ii] +=
              output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw) + oi] *
              filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride)];
            }
          }
        }
      }
    }
  } else {
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, kj, ki)
#endif
    for (img = 0; img < nImg; ++img) {
      for (ifm = 0; ifm < nIfm; ++ifm) {
        for (ofm = 0; ofm < nOfm; ++ofm) {
          for (oj = 0; oj < ofh; ++oj) {
            ij = oj * stride_h - pad_h;
            for (oi = 0; oi < ofw; ++oi) {
              ii = oi * stride_w - pad_w;
              for (kj = 0; kj < kh; ++kj) {
                for (ki = 0; ki < kw; ++ki) {
                    input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij + kj) * ifwp) + (ii + ki)] +=
                    output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw) + oi] *
                    filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw) + ki];
                }
              }
            }
          }
        }
      }
    }
  }
}
