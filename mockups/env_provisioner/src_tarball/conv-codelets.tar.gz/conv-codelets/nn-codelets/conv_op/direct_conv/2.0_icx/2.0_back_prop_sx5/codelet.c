/******************************************************************************
 ** Copyright (c) 2016-2017, Intel Corporation                                **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Redistribution and use in source and binary forms, with or without        **
 ** modification, are permitted provided that the following conditions        **
 ** are met:                                                                  **
 ** 1. Redistributions of source code must retain the above copyright         **
 **    notice, this list of conditions and the following disclaimer.          **
 ** 2. Redistributions in binary form must reproduce the above copyright      **
 **    notice, this list of conditions and the following disclaimer in the    **
 **    documentation and/or other materials provided with the distribution.   **
 ** 3. Neither the name of the copyright holder nor the names of its          **
 **    contributors may be used to endorse or promote products derived        **
 **    from this software without specific prior written permission.          **
 **                                                                           **
 ** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       **
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         **
 ** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     **
 ** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      **
 ** HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    **
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  **
 ** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    **
 ** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    **
 ** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      **
 ** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        **
 ** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              **
 ******************************************************************************/
/* Alexander Heinecke, Hans Pabst, Dhiraj Kalamkar,
 Rajkishore Barik (Intel Corp.)
 ******************************************************************************/

/* Modified by Ankush Mandal (Georgia Tech) */

#include "codelet.h"

void optimized_conv_bp(naive_conv_t* param, float* input, const float* output, const float* filter)
{
  int nImg      = param->nImg;
  int nIfm      = param->nIfm;
  int nOfm      = param->nOfm;
  int ifhp      = param->ifhp;
  int ifwp      = param->ifwp;
  int ifh       = param->ifh;
  int ifw       = param->ifw;
  int ofh       = param->ofh;
  int ofw       = param->ofw;
  int pad_h     = param->pad_h;
  int pad_w     = param->pad_w;
  int kh        = param->kh;
  int kw        = param->kw;
  int stride_h  = param->stride_h;
  int stride_w  = param->stride_w;
  /* loop counters */
  int img, ofm, ifm, oj, oi, ij, ii, kj, ki, ifm1, ofm1;
  int kj_begin, kj_end;
  int ki_begin, ki_end;
#if 1
  ofw = 7;
#endif

  /* strides for array index calculation */
  int input_img_stride  = nIfm * ifhp * ifwp;
  int input_ifm_stride  = ifhp * ifwp * VEC_LENGTH;
  int output_img_stride = nOfm * ofh * ofw;
  int output_ofm_stride = ofh * ofw * VEC_LENGTH;
  int weight_ofm_stride = nIfm * kh * kw * VEC_LENGTH;
  int weight_ifm_stride = kh * kw * VEC_LENGTH * VEC_LENGTH;

  float* input_t        = &input[(pad_h * ifwp + pad_w)*VEC_LENGTH];

#if 0
  if (kh == 1 && kw == 1)
  {
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, kj, ki, ifm1, ofm1)
#endif
#endif
    for (img = 0; img < nImg; ++img) {
      for (ifm = 0; ifm < nIfm/VEC_LENGTH; ++ifm) {
        for (ofm = 0; ofm < nOfm/VEC_LENGTH; ++ofm) {
#if 1
          #pragma unroll_and_jam (16)
#endif
          for (ofm1=0; ofm1 < VEC_LENGTH; ++ofm1) {
            for (oj = 0; oj < ofh; ++oj) {
              ij = oj * stride_h - pad_h;
              #pragma unroll (7)
              for (oi = 0; oi < ofw; ++oi) {
                ii = oi * stride_w - pad_w;
                #pragma vector aligned
                for(ifm1=0; ifm1 < VEC_LENGTH; ++ifm1)
                {
                  input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (ii * VEC_LENGTH) + ifm1] +=
                  output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (oi * VEC_LENGTH) + ofm1] *
                  filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (ofm1*VEC_LENGTH) + ifm1];
                }
              }
            }
          }
        }
      }
    }
#if 0
  } else {
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, kj, ki, ifm1, ofm1)
#endif
    for (img = 0; img < nImg; ++img) {
      for (ifm = 0; ifm < nIfm/VEC_LENGTH; ++ifm) {
        for (ofm = 0; ofm < nOfm/VEC_LENGTH; ++ofm) {
          for (ofm1=0; ofm1 < VEC_LENGTH; ++ofm1) {
            for (oj = 0; oj < ofh; ++oj) {
              ij = oj * stride_h - pad_h;
              kj_begin = (ij < 0) ? -(0+ij) : 0;
              kj_end = (kh-1 + ij) >= ifh ? (ij+kh-ifh+1) : kh;
              for (oi = 0; oi < ofw; ++oi) {
                ii = oi * stride_w - pad_w;
                ki_begin = (ii < 0) ? -(0+ii) : 0;
                ki_end = (kw-1 + ii) >= ifw ? (ii+kw-ifw+1) : kw;
                for (kj = kj_begin; kj < kj_end; ++kj) {
                  for (ki = ki_begin; ki < ki_end; ++ki) {
                    #pragma vector aligned
                    for(ifm1=0; ifm1 < VEC_LENGTH; ++ifm1)
                    {
                      input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij + kj) * ifwp * VEC_LENGTH) + ((ii + ki)*VEC_LENGTH) + ifm1] +=
                      output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (oi*VEC_LENGTH) + ofm1] *
                      filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (ki*VEC_LENGTH * VEC_LENGTH) + (ofm1*VEC_LENGTH) + ifm1 ];
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
#endif
}
