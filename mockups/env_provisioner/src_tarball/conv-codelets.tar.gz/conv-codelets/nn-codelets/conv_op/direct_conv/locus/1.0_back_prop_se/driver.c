/******************************************************************************
 ** Copyright (c) 2016-2017, Intel Corporation                                **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Redistribution and use in source and binary forms, with or without        **
 ** modification, are permitted provided that the following conditions        **
 ** are met:                                                                  **
 ** 1. Redistributions of source code must retain the above copyright         **
 **    notice, this list of conditions and the following disclaimer.          **
 ** 2. Redistributions in binary form must reproduce the above copyright      **
 **    notice, this list of conditions and the following disclaimer in the    **
 **    documentation and/or other materials provided with the distribution.   **
 ** 3. Neither the name of the copyright holder nor the names of its          **
 **    contributors may be used to endorse or promote products derived        **
 **    from this software without specific prior written permission.          **
 **                                                                           **
 ** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       **
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         **
 ** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     **
 ** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      **
 ** HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    **
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  **
 ** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    **
 ** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    **
 ** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      **
 ** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        **
 ** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              **
 ******************************************************************************/
/* Alexander Heinecke, Hans Pabst, Dhiraj Kalamkar,
 Rajkishore Barik (Intel Corp.)
 ******************************************************************************/

/* Modified by Ankush Mandal (Georgia Tech) */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "codelet.h"
#include "measure.h"


inline void zero_buf(float* buf, long size) {
  int i;
  for (i = 0; i < size; ++i) {
    buf[i] = 0.0f;
  }
}

inline void copy_buf(float* src, float* dst, long size) {
  int i;
  for (i = 0; i < size; ++i) {
    dst[i] = src[i];
  }
}

void init_buf(float* buf, long size, int initPos, int initOne)
{
  int i;
  zero_buf(buf, size);
  for (i = 0; i < size; ++i) {
    buf[i] = (float)((initOne != 0) ? 1.0 : ((initPos != 0) ? drand48() : (0.05 - drand48()/10.0)));
  }
}

void set_zeropad_nchw(float* nchw, int N, int C, int H, int W, int pad_h, int pad_w)
{
  int n, h, w, c;

  for ( n = 0; n < N; n++ ) {
    for ( c = 0; c < C; c++ ) {
      for ( h = 0; h < H; h++ ) {
        for ( w = 0; w < W; w++ ) {
          if (h < pad_h || h >= H-pad_h || w < pad_w || w >= W-pad_w)
            nchw[n*C*H*W + c*H*W + h*W + w] = 0.0;
        }
      }
    }
  }
}

int read_arguments (int param[], int* repetitions)
{
  int res = 0;
  int count_conv_arg = 0;
  FILE* file;
  file = fopen ("codelet.data", "r");
  
  if (file != NULL)
  {
    res = fscanf (file, "%d", repetitions);
    if (res != 1)
    {
      fclose (file);
      return -1;
    }
 //   fclose (file);
  } else {
    return -1;
  }
  
//  file = fopen ("conv_layer.data", "r"); 
//  if (file != NULL) 
//  {
    res = fscanf (file, " %d", &param[0]);
    while (res == 1 && count_conv_arg <= 8)
    {
      ++count_conv_arg;
      res = fscanf (file, ":%d", &param[count_conv_arg]);
    }
    if (count_conv_arg != 9 || res != 1)
    {
      fclose (file);
      return -1;
    }
    fclose (file);
    return 0;
//  }
//  return -1;
}

int main(int argc, char* argv[])
{
  float *naive_input, *naive_input_bp, *naive_output, *naive_filter, *naive_filter_wu;
  int ifhp, ifwp, ofh, ofw, stride_h, stride_w, pad_h, pad_w;
  naive_conv_t naive_param;

  /* some parameters we can overwrite via cli,
     default is some inner layer of overfeat */
  int iters = 1;         /* repetitions of benchmark */
  int ifw = 14;           /* input width, "W" */
  int ifh = 14;           /* input height, "H" */
  int nImg = 32;          /* mini-batch size, "N" */
  int nIfm = 128;         /* number of input feature maps, "C" */
  int nOfm = 256;         /* number of output feature maps, "K" */
  int kh = 3;             /* filter height, "R" */
  int kw = 3;             /* filter width, "S" */
  int pad = 0;            /* padding in output */
  int stride = 1;         /* stride when accessing inputs */
  int padding_mode = 0;   /* padding mode */
  char type = 'A';        /* 'A': ALL, 'F': FP, 'B': BP, 'U', WU */
#if defined(_OPENMP)
  int nThreads = omp_get_max_threads();      /* number of threads */
#else
  int nThreads = 1;       /* number of threads */
#endif
  int read_param[10];

  clock_t l_start, l_end;
  double l_total = 0.0;
  double flops = 0.0;
  int i;

  if (argc > 1 && !strncmp(argv[1], "-h", 3)) {
    printf("Usage: %s iters inpWidth inpHeight nImg nIfm nOfm kw kh pad stride type format padding_mode\n", argv[0]);
    return 0;
  }
  srand48(1);

  /* reading new values from cli */
  i = 1;
  if (argc > i) iters      = atoi(argv[i++]);
  if (argc > i) ifw        = atoi(argv[i++]);
  if (argc > i) ifh        = atoi(argv[i++]);
  if (argc > i) nImg       = atoi(argv[i++]);
  if (argc > i) nIfm       = atoi(argv[i++]);
  if (argc > i) nOfm       = atoi(argv[i++]);
  if (argc > i) kw         = atoi(argv[i++]);
  if (argc > i) kh         = atoi(argv[i++]);
  if (argc > i) pad        = atoi(argv[i++]);
  if (argc > i) stride     = atoi(argv[i++]);
  if (argc > i) type       = *(argv[i++]);
  if (argc > i) padding_mode = atoi(argv[i++]);

  if (type != 'A' && type != 'F' && type != 'B' && type != 'U') {
    printf("type needs to be 'A' (All), 'F' (FP only), 'B' (BP only), 'U' (WU only)\n");
    return 0;
  }

  if (read_arguments (read_param, &iters) == -1)
  {
    printf("Failed to load codelet.data!\n");
    return -1;
  } else {
    /* reading new values from codelet.data */
    i = 0;
    ifw        = read_param[i++];
    ifh        = read_param[i++];
    nImg       = read_param[i++];
    nIfm       = read_param[i++];
    nOfm       = read_param[i++];
    kw         = read_param[i++];
    kh         = read_param[i++];
    pad        = read_param[i++];
    pad        = read_param[i++];
    stride     = read_param[i];
  }

  stride_w = stride;
  stride_h = stride;
  pad_h = pad;
  pad_w = pad;


  /* deriving some values for naive code */
  ofh = (ifh + 2 * pad_h - kh) / stride_h + 1;
  ofw = (ifw + 2 * pad_w - kw) / stride_w + 1;
  ifhp = ifh + 2 * pad_h;
  ifwp = ifw + 2 * pad_w;

  /* set struct for naive convolution */
  naive_param.nImg = nImg;
  naive_param.nIfm = nIfm;
  naive_param.nOfm = nOfm;
  naive_param.ifhp = ifhp;
  naive_param.ifwp = ifwp;
  naive_param.ifh = ifh;
  naive_param.ifw = ifw;
  naive_param.ofh = ofh;
  naive_param.ofw = ofw;
  naive_param.pad_h = pad_h;
  naive_param.pad_w = pad_w;
  naive_param.kh = kh;
  naive_param.kw = kw;
  naive_param.stride_h = stride_h;
  naive_param.stride_w = stride_w;

  /* print some summary */
  printf("##########################################\n");
  printf("#          Setting Up (Common)           #\n");
  printf("##########################################\n");
  printf("PARAMS: W:%d  H:%d  N:%d  C:%d  K:%d  R:%d  S:%d  P:%d  Q:%d  STRIDE:%d  PAD:%d\n", ifw, ifh, nImg, nIfm, nOfm, kw, kh, ofh, ofw, stride, pad);
  printf("PARAMS: ITERS:%d  Threads:%d\n", iters, nThreads);
  printf("InImg %dx%d Padded (%dx%d)\n", ifh, ifw, ifhp, ifwp);
  printf("OutImg %dx%d\n", ofh, ofw);
  printf("SIZE Input  (MB): %10.2f MiB\n", (double)(nImg*nIfm*ifhp*ifwp*sizeof(float))/(1024.0*1024.0) );
  printf("SIZE Output (MB): %10.2f MiB\n", (double)(nImg*nOfm*ofh*ofw*  sizeof(float))/(1024.0*1024.0) );
  printf("SIZE Input   (1): %10.2f MiB\n", (double)(1*nIfm*ifhp*ifwp*   sizeof(float))/(1024.0*1024.0) );
  printf("SIZE Output  (1): %10.2f MiB\n", (double)(1*nOfm*ofh*ofw*     sizeof(float))/(1024.0*1024.0) );
  printf("SIZE Weight     : %10.2f MiB\n", (double)(nIfm*nOfm*kw*kh*    sizeof(float))/(1024.0*1024.0) );

  /* allocate data */
  naive_input           = (float*)malloc( nImg*nIfm*ifhp*ifwp*sizeof(float));
  naive_input_bp        = (float*)malloc( nImg*nIfm*ifhp*ifwp*sizeof(float));
  naive_output          = (float*)malloc( nImg*nOfm*ofh*ofw*  sizeof(float));
  naive_filter          = (float*)malloc( nOfm*nIfm*kh*kw*    sizeof(float));
  naive_filter_wu       = (float*)malloc( nOfm*nIfm*kh*kw*    sizeof(float));

  /* initialize data */
  init_buf(naive_input,          nImg*nIfm*ifhp*ifwp, 0, 0);
  set_zeropad_nchw(naive_input, nImg, nIfm, ifhp, ifwp, pad_h, pad_w);
  copy_buf(naive_input, naive_input_bp, nImg*nIfm*ifhp*ifwp);
  init_buf(naive_output,         nImg*nOfm*ofh*ofw, 0, 0);
  init_buf(naive_filter,         nOfm*nIfm*kh*kw, 0, 0);
  copy_buf(naive_filter, naive_filter_wu, nOfm*nIfm*kh*kw);


  printf("##########################################\n");
  printf("#         Computing Reference ...        #\n");
  printf("##########################################\n");
  if (type == 'A' || type == 'B') {
    //l_start = clock();
    measure_init_();
    measure_sec_spin_(15);
    measure_start_();
    for (i = 0; i < iters; ++i) {
      naive_conv_bp(&naive_param, naive_input_bp, naive_output, naive_filter);
    }
    measure_stop_();
    //l_end = clock();
    //l_total = (double)(l_end - l_start) / CLOCKS_PER_SEC;
    //flops = (double)nImg * (double)nIfm * (double)nOfm * (double)ofh * (double)ofw * (double)(2 * kh * kw) * (double)iters;
    //printf("Naive bp GFLOPS  = %.5g\n", (flops*1e-9)/l_total);
  }
  /*
  if (type == 'A' || type == 'U') {
    l_start = clock();
    for (i = 0; i < iters; ++i) {
      naive_conv_wu(&naive_param, naive_input, naive_output, naive_filter_wu);
    }
    l_end = clock();
    l_total = (double)(l_end - l_start) / CLOCKS_PER_SEC;
    flops = (double)nImg * (double)nIfm * (double)nOfm * (double)ofh * (double)ofw * (double)(2 * kh * kw) * (double)iters;
    printf("Naive upd GFLOPS  = %.5g\n", (flops*1e-9)/l_total);
  }*/
  printf("##########################################\n");
  printf("#      Computing Reference ... done      #\n");
  printf("##########################################\n");

  /* deallocate data */
  free(naive_input);
  free(naive_input_bp);
  free(naive_output);
  free(naive_filter);
  free(naive_filter_wu);
  /* some empty lines at the end */
  printf("\n\n\n");

  return 0;
}
