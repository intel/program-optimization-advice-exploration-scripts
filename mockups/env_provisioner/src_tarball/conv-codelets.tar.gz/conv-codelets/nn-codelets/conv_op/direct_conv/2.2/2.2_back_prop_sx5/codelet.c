/******************************************************************************
 ** Copyright (c) 2016-2017, Intel Corporation                                **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Redistribution and use in source and binary forms, with or without        **
 ** modification, are permitted provided that the following conditions        **
 ** are met:                                                                  **
 ** 1. Redistributions of source code must retain the above copyright         **
 **    notice, this list of conditions and the following disclaimer.          **
 ** 2. Redistributions in binary form must reproduce the above copyright      **
 **    notice, this list of conditions and the following disclaimer in the    **
 **    documentation and/or other materials provided with the distribution.   **
 ** 3. Neither the name of the copyright holder nor the names of its          **
 **    contributors may be used to endorse or promote products derived        **
 **    from this software without specific prior written permission.          **
 **                                                                           **
 ** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       **
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         **
 ** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     **
 ** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      **
 ** HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    **
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  **
 ** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    **
 ** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    **
 ** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      **
 ** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        **
 ** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              **
 ******************************************************************************/
/* Alexander Heinecke, Hans Pabst, Dhiraj Kalamkar,
 Rajkishore Barik (Intel Corp.)
 ******************************************************************************/

/* Modified by Ankush Mandal (Georgia Tech) */

#include <immintrin.h>
#include "codelet.h"

void cache_block_conv_bp(naive_conv_t* param, float* input, const float* output, const float* filter)
{
  int nImg      = param->nImg;
  int nIfm      = param->nIfm;
  int nOfm      = param->nOfm;
  int ifhp      = param->ifhp;
  int ifwp      = param->ifwp;
  int ifh       = param->ifh;
  int ifw       = param->ifw;
  int ofh       = param->ofh;
  int ofw       = param->ofw;
  int pad_h     = param->pad_h;
  int pad_w     = param->pad_w;
  int kh        = param->kh;
  int kw        = param->kw;
  int stride_h  = param->stride_h;
  int stride_w  = param->stride_w;
  /* loop counters */
  int img, ofm, ifm, oj, oi, ij, ii, kj, ki, ifm1, ofm1, oi_b;
  int kj_begin, kj_end;
  int ki_begin, ki_end;
  
  /* strides for array index calculation */
  int input_img_stride  = nIfm * ifhp * ifwp;
  int input_ifm_stride  = ifhp * ifwp * VEC_LENGTH;
  int output_img_stride = nOfm * ofh * ofw;
  int output_ofm_stride = ofh * ofw * VEC_LENGTH;
  int weight_ofm_stride = nIfm * kh * kw * VEC_LENGTH;
  int weight_ifm_stride = kh * kw * VEC_LENGTH * VEC_LENGTH;

  float* input_t        = &input[(pad_h * ifwp + pad_w)*VEC_LENGTH];

  if (kh == 1 && kw == 1)
  {
    switch (ofw) {
      case 7:
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, ifm1, ofm1, oi_b)
#endif
        for (img = 0; img < nImg; ++img) {
          for (ifm = 0; ifm < nIfm/VEC_LENGTH; ++ifm) {
            for (ofm = 0; ofm < nOfm/VEC_LENGTH; ++ofm) {
              for (oj = 0; oj < ofh; ++oj) {
                ij = oj;
                __m512 zmm28, zmm29, zmm30, zmm31;
                zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (0 * VEC_LENGTH)]);
                zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (1 * VEC_LENGTH)]);
                zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (2 * VEC_LENGTH)]);
                zmm28 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (3 * VEC_LENGTH)]);

                __m512 zmm0, zmm1, zmm2, zmm3, zmm4, zmm5, zmm6;
                zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (0 * VEC_LENGTH)]);
                zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (1 * VEC_LENGTH)]);
                zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (2 * VEC_LENGTH)]);
                zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (3 * VEC_LENGTH)]);
                zmm4 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (4 * VEC_LENGTH)]); 
                zmm5 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (5 * VEC_LENGTH)]); 
                zmm6 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (6 * VEC_LENGTH)]); 
#include "7_1x1_vfma.c"                  
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (0 * VEC_LENGTH)], zmm0);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (1 * VEC_LENGTH)], zmm1);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (2 * VEC_LENGTH)], zmm2);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (3 * VEC_LENGTH)], zmm3);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (4 * VEC_LENGTH)], zmm4);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (5 * VEC_LENGTH)], zmm5);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (6 * VEC_LENGTH)], zmm6);
              }
            }
          }
        }
        break;

      case 14:
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, ifm1, ofm1, oi_b)
#endif
        for (img = 0; img < nImg; ++img) {
          for (ifm = 0; ifm < nIfm/VEC_LENGTH; ++ifm) {
            for (ofm = 0; ofm < nOfm/VEC_LENGTH; ++ofm) {
              for (oj = 0; oj < ofh; ++oj) {
                ij = oj;
                __m512 zmm28, zmm29, zmm30, zmm31;
                zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (0 * VEC_LENGTH)]);
                zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (1 * VEC_LENGTH)]);
                zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (2 * VEC_LENGTH)]);
                zmm28 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (3 * VEC_LENGTH)]);

                __m512 zmm0, zmm1, zmm2, zmm3, zmm4, zmm5, zmm6, zmm7, zmm8, zmm9, zmm10, zmm11, zmm12, zmm13;
                zmm0  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (0  * VEC_LENGTH)]);
                zmm1  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (1  * VEC_LENGTH)]);
                zmm2  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (2  * VEC_LENGTH)]);
                zmm3  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (3  * VEC_LENGTH)]);
                zmm4  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (4  * VEC_LENGTH)]); 
                zmm5  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (5  * VEC_LENGTH)]); 
                zmm6  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (6  * VEC_LENGTH)]); 
                zmm7  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (7  * VEC_LENGTH)]); 
                zmm8  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (8  * VEC_LENGTH)]); 
                zmm9  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (9  * VEC_LENGTH)]); 
                zmm10 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (10 * VEC_LENGTH)]); 
                zmm11 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (11 * VEC_LENGTH)]); 
                zmm12 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (12 * VEC_LENGTH)]); 
                zmm13 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (13 * VEC_LENGTH)]); 
                
#include "14_1x1_vfma.c"                  
                
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (0  * VEC_LENGTH)],  zmm0);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (1  * VEC_LENGTH)],  zmm1);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (2  * VEC_LENGTH)],  zmm2);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (3  * VEC_LENGTH)],  zmm3);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (4  * VEC_LENGTH)],  zmm4);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (5  * VEC_LENGTH)],  zmm5);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (6  * VEC_LENGTH)],  zmm6);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (7  * VEC_LENGTH)],  zmm7);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (8  * VEC_LENGTH)],  zmm8);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (9  * VEC_LENGTH)],  zmm9);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (10 * VEC_LENGTH)], zmm10);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (11 * VEC_LENGTH)], zmm11);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (12 * VEC_LENGTH)], zmm12);
                _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (13 * VEC_LENGTH)], zmm13);
              }
            }
          }
        }
        break;

      default:
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, ifm1, ofm1, oi_b)
#endif
        for (img = 0; img < nImg; ++img) {
          for (ifm = 0; ifm < nIfm/VEC_LENGTH; ++ifm) {
            for (ofm = 0; ofm < nOfm/VEC_LENGTH; ++ofm) {
              for (oj = 0; oj < ofh; ++oj) {
                ij = oj;
                __m512 zmm28, zmm29, zmm30, zmm31;
                __m512 zmm0, zmm1, zmm2, zmm3, zmm4, zmm5, zmm6, zmm7, zmm8, zmm9, zmm10, zmm11, zmm12, zmm13;
                for (oi_b = 0; oi_b < (ofw/14); ++oi_b) {
                  oi = oi_b*14;
                  ii = oi;
                  zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (0 * VEC_LENGTH)]);
                  zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (1 * VEC_LENGTH)]);
                  zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (2 * VEC_LENGTH)]);
                  zmm28 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (3 * VEC_LENGTH)]);

                  zmm0  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (ii      * VEC_LENGTH)]);
                  zmm1  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+1 ) * VEC_LENGTH)]);
                  zmm2  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+2 ) * VEC_LENGTH)]);
                  zmm3  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+3 ) * VEC_LENGTH)]);
                  zmm4  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+4 ) * VEC_LENGTH)]); 
                  zmm5  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+5 ) * VEC_LENGTH)]); 
                  zmm6  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+6 ) * VEC_LENGTH)]); 
                  zmm7  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+7 ) * VEC_LENGTH)]); 
                  zmm8  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+8 ) * VEC_LENGTH)]); 
                  zmm9  = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+9 ) * VEC_LENGTH)]); 
                  zmm10 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+10) * VEC_LENGTH)]); 
                  zmm11 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+11) * VEC_LENGTH)]); 
                  zmm12 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+12) * VEC_LENGTH)]); 
                  zmm13 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+13) * VEC_LENGTH)]); 
                  
#include "generic_1x1_vfma.c"                  

                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + (ii      * VEC_LENGTH)],  zmm0);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+1 ) * VEC_LENGTH)],  zmm1);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+2 ) * VEC_LENGTH)],  zmm2);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+3 ) * VEC_LENGTH)],  zmm3);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+4 ) * VEC_LENGTH)],  zmm4);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+5 ) * VEC_LENGTH)],  zmm5);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+6 ) * VEC_LENGTH)],  zmm6);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+7 ) * VEC_LENGTH)],  zmm7);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+8 ) * VEC_LENGTH)],  zmm8);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+9 ) * VEC_LENGTH)],  zmm9);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+10) * VEC_LENGTH)], zmm10);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+11) * VEC_LENGTH)], zmm11);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+12) * VEC_LENGTH)], zmm12);
                  _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + (ij * ifwp * VEC_LENGTH) + ((ii+13) * VEC_LENGTH)], zmm13);
                }
              }
            }
          }
        }
    } 
  } else if (kh == 3 && kw == 3) {
    switch (ofw) {
      case 7:
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, kj, ki, ifm1, ofm1, oi_b, kj_begin, kj_end)
#endif
        for (img = 0; img < nImg; ++img) {
          for (ifm = 0; ifm < nIfm/VEC_LENGTH; ++ifm) {
            for (ofm = 0; ofm < nOfm/VEC_LENGTH; ++ofm) {
              for (oj = 0; oj < ofh; ++oj) {
                ij = oj * stride_h - pad_h;
                kj_begin = (ij < 0) ? -(0+ij) : 0;
                kj_end = (kh-1 + ij) >= ifh ? (ifh-ij) : kh;
                __m512 zmm0, zmm1, zmm2, zmm3, zmm4, zmm5, zmm6;
                __m512 zmm29, zmm30, zmm31; 
                ii = -1;
                for (kj = kj_begin; kj < kj_end; ++kj) {
                  for (ofm1 = 0; ofm1 < VEC_LENGTH; ++ofm1) {
                  //ki is unrolled
                    zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (0 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                    zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (1 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                    zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (2 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                    
                    zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)]);
                    zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)]);
                    zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)]);
                    zmm4 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)]); 
                    zmm5 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)]); 
                    zmm6 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)]); 
                    
                    zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm31, zmm1);
                    zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm31, zmm2);
                    zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm31, zmm3);
                    zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm31, zmm4);
                    zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm31, zmm5);
                    zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm31, zmm6);

                    zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)]);

                    zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + ofm1]), zmm30, zmm1);
                    zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm30, zmm2);
                    zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm30, zmm3);
                    zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm30, zmm4);
                    zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm30, zmm5);
                    zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm30, zmm6);
                    zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm30, zmm0);

                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)], zmm1);
                    
                    zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + ofm1]), zmm29, zmm2);
                    zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm29, zmm3);
                    zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm29, zmm4);
                    zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm29, zmm5);
                    zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm29, zmm6);
                    zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm29, zmm0);

                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)], zmm2);
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)], zmm3);
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)], zmm4);
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)], zmm5);
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)], zmm6);
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)], zmm0);
                  }
                }
              }
            }
          }
        }
        break;

      default:
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, kj, ki, ifm1, ofm1, oi_b, kj_begin, kj_end)
#endif
        for (img = 0; img < nImg; ++img) {
          for (ifm = 0; ifm < nIfm/VEC_LENGTH; ++ifm) {
            for (ofm = 0; ofm < nOfm/VEC_LENGTH; ++ofm) {
                for (oj = 0; oj < ofh; ++oj) {
                  ij = oj * stride_h - pad_h;
                  kj_begin = (ij < 0) ? -(0+ij) : 0;
                  kj_end = (kh-1 + ij) >= ifh ? (ifh-ij) : kh;
                  __m512 zmm0, zmm1, zmm2, zmm3, zmm4, zmm5, zmm6, zmm29, zmm30, zmm31;
                  for (oi_b = 0; oi_b < (ofw/7); ++oi_b) {
                    oi = oi_b * 7;
                    ii = oi - 1;
                    for (kj = kj_begin; kj < kj_end; ++kj) {
                      for (ofm1=0; ofm1 < VEC_LENGTH; ++ofm1) {
                        //ki is unrolled
                        zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (0 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                        zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (1 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                        zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (2 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                        if (oi_b == 0) {
                          zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)]);
                          zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)]);
                          zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)]);
                          zmm4 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)]); 
                          zmm5 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)]); 
                          zmm6 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)]); 
                          
                          zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm31, zmm1);
                          zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm31, zmm2);
                          zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm31, zmm3);
                          zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm31, zmm4);
                          zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm31, zmm5);
                          zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm31, zmm6);

                          zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)]);
                          
                          zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm30, zmm1);
                          zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm30, zmm2);
                          zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm30, zmm3);
                          zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm30, zmm4);
                          zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm30, zmm5);
                          zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm30, zmm6);
                          zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm30, zmm0);

                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)], zmm1);
                          zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)]);
                          
                          zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm29, zmm2);
                          zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm29, zmm3);
                          zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm29, zmm4);
                          zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm29, zmm5);
                          zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm29, zmm6);
                          zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm29, zmm0);
                          zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm29, zmm1);

                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)], zmm2);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)], zmm3);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)], zmm4);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)], zmm5);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)], zmm6);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)], zmm0);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)], zmm1);

                        } else if (oi_b == ((ofw/7)-1)) {
                          zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+0) * VEC_LENGTH)]);
                          zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)]);
                          zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)]);
                          zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)]);
                          zmm4 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)]); 
                          zmm5 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)]); 
                          zmm6 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)]); 
                          
                          zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm31, zmm0);
                          zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm31, zmm1);
                          zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm31, zmm2);
                          zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm31, zmm3);
                          zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm31, zmm4);
                          zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm31, zmm5);
                          zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm31, zmm6);

                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+0) * VEC_LENGTH)], zmm0);
                          zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)]);
                          
                          zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm30, zmm1);
                          zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm30, zmm2);
                          zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm30, zmm3);
                          zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm30, zmm4);
                          zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm30, zmm5);
                          zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm30, zmm6);
                          zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm30, zmm0);

                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)], zmm1);
                          
                          zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm29, zmm2);
                          zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm29, zmm3);
                          zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm29, zmm4);
                          zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm29, zmm5);
                          zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm29, zmm6);
                          zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm29, zmm0);

                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)], zmm2);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)], zmm3);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)], zmm4);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)], zmm5);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)], zmm6);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)], zmm0);

                        } else {
                          zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+0) * VEC_LENGTH)]);
                          zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)]);
                          zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)]);
                          zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)]);
                          zmm4 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)]); 
                          zmm5 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)]); 
                          zmm6 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)]); 
                          
                          zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm31, zmm0);
                          zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm31, zmm1);
                          zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm31, zmm2);
                          zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm31, zmm3);
                          zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm31, zmm4);
                          zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm31, zmm5);
                          zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm31, zmm6);

                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+0) * VEC_LENGTH)], zmm0);
                          zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)]);
                          
                          zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm30, zmm1);
                          zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm30, zmm2);
                          zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm30, zmm3);
                          zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm30, zmm4);
                          zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm30, zmm5);
                          zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm30, zmm6);
                          zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm30, zmm0);
                          
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)], zmm1);
                          zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)]);
                          
                          zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm29, zmm2);
                          zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm29, zmm3);
                          zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm29, zmm4);
                          zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm29, zmm5);
                          zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm29, zmm6);
                          zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm29, zmm0);
                          zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm29, zmm1);

                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)], zmm2);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)], zmm3);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)], zmm4);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)], zmm5);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)], zmm6);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)], zmm0);
                          _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)], zmm1);
                      }
                    }
                  }
                }
              }
            }
          }
        }
    }
  } else if (kh == 5 && kw == 5) {
    switch (ofw) {
      case 7:
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, kj, ki, ifm1, ofm1, oi_b, kj_begin, kj_end)
#endif
        for (img = 0; img < nImg; ++img) {
          for (ifm = 0; ifm < nIfm/VEC_LENGTH; ++ifm) {
            for (ofm = 0; ofm < nOfm/VEC_LENGTH; ++ofm) {
                for (oj = 0; oj < ofh; ++oj) {
                  ij = oj * stride_h - pad_h;
                  kj_begin = (ij < 0) ? -(0+ij) : 0;
                  kj_end = (kh-1 + ij) >= ifh ? (ifh-ij) : kh;
                  __m512 zmm0, zmm1, zmm2, zmm3, zmm4, zmm5, zmm6, zmm27, zmm28, zmm29, zmm30, zmm31;
                  ii = -2;
                  for (kj = kj_begin; kj < kj_end; ++kj) {
                    for (ofm1=0; ofm1 < VEC_LENGTH; ++ofm1) {
                    //ki is unrolled
                    zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (0 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                    zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (1 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                    zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (2 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                    
                    zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)]);
                    zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)]);
                    zmm4 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)]); 
                    zmm5 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)]); 
                    zmm6 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)]); 
                    
                    zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm31, zmm2);
                    zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm31, zmm3);
                    zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm31, zmm4);
                    zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm31, zmm5);
                    zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm31, zmm6);

                    zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)]);
                    zmm28 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (3 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                    
                    zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm30, zmm2);
                    zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm30, zmm3);
                    zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm30, zmm4);
                    zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm30, zmm5);
                    zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm30, zmm6);
                    zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm30, zmm0);

                    zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)]);
                    zmm27 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (4 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);

                    zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + ofm1]), zmm29, zmm2);
                    zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm29, zmm3);
                    zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm29, zmm4);
                    zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm29, zmm5);
                    zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm29, zmm6);
                    zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm29, zmm0);
                    zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm29, zmm1);

                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)], zmm2);

                    zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + ofm1]), zmm28, zmm3);
                    zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm28, zmm4);
                    zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm28, zmm5);
                    zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm28, zmm6);
                    zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm28, zmm0);
                    zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm28, zmm1);

                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)], zmm3);

                    zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + ofm1]), zmm27, zmm4);
                    zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm27, zmm5);
                    zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm27, zmm6);
                    zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm27, zmm0);
                    zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm27, zmm1);
                    
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)], zmm4);
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)], zmm5);
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)], zmm6);
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)], zmm0);
                    _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)], zmm1);
                  }
                }
              }
            }
          }
        }
        break;

      default:
#if defined(_OPENMP)
#pragma omp parallel for collapse(2) private(img, ofm, ifm, oj, oi, ij, ii, kj, ki, ifm1, ofm1, oi_b, kj_begin, kj_end)
#endif
        for (img = 0; img < nImg; ++img) {
          for (ifm = 0; ifm < nIfm/VEC_LENGTH; ++ifm) {
            for (ofm = 0; ofm < nOfm/VEC_LENGTH; ++ofm) {
                for (oj = 0; oj < ofh; ++oj) {
                  ij = oj * stride_h - pad_h;
                  kj_begin = (ij < 0) ? -(0+ij) : 0;
                  kj_end = (kh-1 + ij) >= ifh ? (ifh-ij) : kh;
                  __m512 zmm0, zmm1, zmm2, zmm3, zmm4, zmm5, zmm6, zmm27, zmm28, zmm29, zmm30, zmm31;
                  for (oi_b = 0; oi_b < (ofw/7); ++oi_b) {
                    oi = oi_b * 7;
                    ii = oi - 2;
                    for (kj = kj_begin; kj < kj_end; ++kj) {
                      for (ofm1=0; ofm1 < VEC_LENGTH; ++ofm1) {
                      //ki is unrolled
                      zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (0 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                      zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (1 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                      zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (2 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                      zmm28 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (3 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);
                      zmm27 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (kj * kw * VEC_LENGTH * VEC_LENGTH) + (4 * VEC_LENGTH * VEC_LENGTH) + (ofm1 * VEC_LENGTH)]);

                      if (oi_b == 0) {
                        zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)]);
                        zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)]);
                        zmm4 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)]); 
                        zmm5 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)]); 
                        zmm6 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)]); 
                        
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm31, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm31, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm31, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm31, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm31, zmm6);

                        zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)]);
                        
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm30, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm30, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm30, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm30, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm30, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm30, zmm0);

                        zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)]);

                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + ofm1]), zmm29, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm29, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm29, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm29, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm29, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm29, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm29, zmm1);

                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)], zmm2);
                        zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+9) * VEC_LENGTH)]);

                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + ofm1]), zmm28, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm28, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm28, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm28, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm28, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm28, zmm1);
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm28, zmm2);

                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)], zmm3);
                        zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+10) * VEC_LENGTH)]);

                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + ofm1]), zmm27, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + ofm1]), zmm27, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + ofm1]), zmm27, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + ofm1]), zmm27, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + ofm1]), zmm27, zmm1);
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + ofm1]), zmm27, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + ofm1]), zmm27, zmm3);
                        
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)], zmm4);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)], zmm5);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)], zmm6);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)], zmm0);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)], zmm1);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+9) * VEC_LENGTH)], zmm2);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+10) * VEC_LENGTH)], zmm3);

                      } else if (oi_b == ((ofw/7)-1)) {
                        zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+0) * VEC_LENGTH)]);
                        zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)]);
                        zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)]);
                        zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)]);
                        zmm4 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)]); 
                        zmm5 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)]); 
                        zmm6 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)]); 
                        
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm31, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm31, zmm1);
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm31, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm31, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm31, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm31, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm31, zmm6);

                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+0) * VEC_LENGTH)], zmm0);
                        zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)]);
                        
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm30, zmm1);
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm30, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm30, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm30, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm30, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm30, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm30, zmm0);

                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)], zmm1);
                        zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)]);

                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm29, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm29, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm29, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm29, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm29, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm29, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm29, zmm1);

                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)], zmm2);

                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm28, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm28, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm28, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm28, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm28, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm28, zmm1);

                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)], zmm3);

                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm27, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm27, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm27, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm27, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm27, zmm1);
                        
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)], zmm4);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)], zmm5);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)], zmm6);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)], zmm0);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)], zmm1);

                      } else {
                        zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+0) * VEC_LENGTH)]);
                        zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)]);
                        zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)]);
                        zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)]);
                        zmm4 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)]); 
                        zmm5 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)]); 
                        zmm6 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)]); 
                        
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm31, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm31, zmm1);
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm31, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm31, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm31, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm31, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm31, zmm6);

                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+0) * VEC_LENGTH)], zmm0);
                        zmm0 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)]);
                        
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm30, zmm1);
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm30, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm30, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm30, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm30, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm30, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm30, zmm0);

                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+1) * VEC_LENGTH)], zmm1);
                        zmm1 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)]);

                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm29, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm29, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm29, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm29, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm29, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm29, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm29, zmm1);
                        
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+2) * VEC_LENGTH)], zmm2);
                        zmm2 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+9) * VEC_LENGTH)]);

                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm28, zmm3);
                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm28, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm28, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm28, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm28, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm28, zmm1);
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm28, zmm2);

                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+3) * VEC_LENGTH)], zmm3);
                        zmm3 = _mm512_load_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+10) * VEC_LENGTH)]);

                        zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+0) * VEC_LENGTH) + ofm1]), zmm27, zmm4);
                        zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+1) * VEC_LENGTH) + ofm1]), zmm27, zmm5);
                        zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+2) * VEC_LENGTH) + ofm1]), zmm27, zmm6);
                        zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+3) * VEC_LENGTH) + ofm1]), zmm27, zmm0);
                        zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+4) * VEC_LENGTH) + ofm1]), zmm27, zmm1);
                        zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+5) * VEC_LENGTH) + ofm1]), zmm27, zmm2);
                        zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + ((oi+6) * VEC_LENGTH) + ofm1]), zmm27, zmm3);
                        
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+4) * VEC_LENGTH)], zmm4);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+5) * VEC_LENGTH)], zmm5);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+6) * VEC_LENGTH)], zmm6);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+7) * VEC_LENGTH)], zmm0);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+8) * VEC_LENGTH)], zmm1);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+9) * VEC_LENGTH)], zmm2);
                        _mm512_store_ps (&input_t[(img * input_img_stride) + (ifm * input_ifm_stride) + ((ij+kj) * ifwp * VEC_LENGTH) + ((ii+10) * VEC_LENGTH)], zmm3);
                      }
                    }
                  }
                }
              }
            }
          }
        }
    }
  }
}
