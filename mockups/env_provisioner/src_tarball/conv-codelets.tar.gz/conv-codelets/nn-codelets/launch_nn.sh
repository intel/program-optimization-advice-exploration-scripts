#!/bin/bash
LAYER=1
while read -r line || [[ -n "${line}" ]]; do
  cd ../cape-experiment-scripts/vrun
  ((LAYER+=1))
  echo "Running layer${LAYER} ..."
  echo "${line}" 
  echo "${line}" > ../../nn-codelets/GoogleNet_V1.txt
  echo "1 ${line}" > ../../nn-codelets/conv_op/direct_conv/naive_impl/back_prop/codelet.data
  echo "application name=GoogleNet_V1_layer${LAYER}" > ../../nn-codelets/conv_op/direct_conv/naive_impl/back_prop/codelet.meta
  echo "batch name=direct_conv" >> ../../nn-codelets/conv_op/direct_conv/naive_impl/back_prop/codelet.meta
  echo "code name=1.0" >> ../../nn-codelets/conv_op/direct_conv/naive_impl/back_prop/codelet.meta
  echo "codelet name=back_prop_se" >> ../../nn-codelets/conv_op/direct_conv/naive_impl/back_prop/codelet.meta
  ./vrun_ancodskx1020_nn.sh "GoogleNet_V1_layer${LAYER}" || true
  cd ../../nn-codelets
done < "$1"
