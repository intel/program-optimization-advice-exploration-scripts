#!/usr/bin/env bash

export ICELOCUS_CC='icc' #'gcc-7'
# Save at the locus.db some info about the input
export ICELOCUS_CODELETDATA=`cat codelet.data | head -n 1 | awk '{print $2}'`

stopaf=500 #5000
ntests=200 #1000
uplimit=100 # in seconds
cfile=codelet.c
locusfile=conv.locus

hyptool="ice-locus-hyperopt.py"
hypargs="--hypalg ${hypalg} --hypmixdsc ${hypmixdsc}"

otutool="ice-locus-opentuner.py"
otuargs="--otprune"

exhtool='ice-locus-exhaustive.py'
exhargs='--debug' #'--convonly'

#setool="$otutool"
setool="$exhtool"

if [ $setool = "$hyptool" ]; then
    seargs=$hypargs
elif [ $setool = "$otutool" ]; then
    seargs=$otuargs
    rm -rvf opentuner.db opentuner.log
elif [ $setool = "$exhtool" ]; then
    seargs=$exhargs
else
    echo "ERROR! Tool $setoll not recognized!"
    exit
fi

#seargs+="--debug --convonly"
#seargs+="--initseed"
#seargs+="--upper-limit ${uplimit}"
seargs+=" --stop-after $stopaf --timeout "

set -x
$setool $seargs \
    -t ${locusfile} -f $cfile \
    --tfunc mytiming.py:getTimingMatMul -o suffix \
    -u '.ice' --search --ntests ${ntests}
set +x
