                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 0]), zmm31, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 0]), zmm31, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 0]), zmm31, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 0]), zmm31, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 0]), zmm31, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 0]), zmm31, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 0]), zmm31, zmm6);

                  zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (4 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 1]), zmm30, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 1]), zmm30, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 1]), zmm30, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 1]), zmm30, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 1]), zmm30, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 1]), zmm30, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 1]), zmm30, zmm6);

                  zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (5 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 2]), zmm29, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 2]), zmm29, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 2]), zmm29, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 2]), zmm29, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 2]), zmm29, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 2]), zmm29, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 2]), zmm29, zmm6);

                  zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (6 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 3]), zmm28, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 3]), zmm28, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 3]), zmm28, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 3]), zmm28, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 3]), zmm28, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 3]), zmm28, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 3]), zmm28, zmm6);

                  zmm28 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (7 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 4]), zmm31, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 4]), zmm31, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 4]), zmm31, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 4]), zmm31, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 4]), zmm31, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 4]), zmm31, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 4]), zmm31, zmm6);

                  zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (8 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 5]), zmm30, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 5]), zmm30, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 5]), zmm30, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 5]), zmm30, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 5]), zmm30, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 5]), zmm30, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 5]), zmm30, zmm6);

                  zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (9 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 6]), zmm29, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 6]), zmm29, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 6]), zmm29, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 6]), zmm29, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 6]), zmm29, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 6]), zmm29, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 6]), zmm29, zmm6);

                  zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (10 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 7]), zmm28, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 7]), zmm28, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 7]), zmm28, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 7]), zmm28, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 7]), zmm28, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 7]), zmm28, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 7]), zmm28, zmm6);

                  zmm28 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (11 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 8]), zmm31, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 8]), zmm31, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 8]), zmm31, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 8]), zmm31, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 8]), zmm31, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 8]), zmm31, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 8]), zmm31, zmm6);

                  zmm31 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (12 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 9]), zmm30, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 9]), zmm30, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 9]), zmm30, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 9]), zmm30, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 9]), zmm30, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 9]), zmm30, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 9]), zmm30, zmm6);

                  zmm30 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (13 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 10]), zmm29, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 10]), zmm29, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 10]), zmm29, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 10]), zmm29, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 10]), zmm29, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 10]), zmm29, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 10]), zmm29, zmm6);

                  zmm29 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (14 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 11]), zmm28, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 11]), zmm28, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 11]), zmm28, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 11]), zmm28, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 11]), zmm28, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 11]), zmm28, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 11]), zmm28, zmm6);

                  zmm28 = _mm512_load_ps (&filter[(ofm * weight_ofm_stride) + (ifm * weight_ifm_stride) + (15 * VEC_LENGTH)]);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 12]), zmm31, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 12]), zmm31, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 12]), zmm31, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 12]), zmm31, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 12]), zmm31, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 12]), zmm31, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 12]), zmm31, zmm6);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 13]), zmm30, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 13]), zmm30, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 13]), zmm30, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 13]), zmm30, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 13]), zmm30, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 13]), zmm30, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 13]), zmm30, zmm6);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 14]), zmm29, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 14]), zmm29, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 14]), zmm29, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 14]), zmm29, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 14]), zmm29, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 14]), zmm29, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 14]), zmm29, zmm6);

                  zmm0 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (0 * VEC_LENGTH) + 15]), zmm28, zmm0);
                  zmm1 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (1 * VEC_LENGTH) + 15]), zmm28, zmm1);
                  zmm2 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (2 * VEC_LENGTH) + 15]), zmm28, zmm2);
                  zmm3 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (3 * VEC_LENGTH) + 15]), zmm28, zmm3);
                  zmm4 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (4 * VEC_LENGTH) + 15]), zmm28, zmm4);
                  zmm5 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (5 * VEC_LENGTH) + 15]), zmm28, zmm5);
                  zmm6 = _mm512_fmadd_ps (_mm512_set1_ps(output[(img * output_img_stride) + (ofm * output_ofm_stride) + (oj * ofw * VEC_LENGTH) + (6 * VEC_LENGTH) + 15]), zmm28, zmm6);

