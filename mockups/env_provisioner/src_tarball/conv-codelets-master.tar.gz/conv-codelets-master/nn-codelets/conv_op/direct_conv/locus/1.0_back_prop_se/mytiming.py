import re, statistics as stat

def getTimingMatMul(std, error):
    result = {'metric' : 'N/A'}
    with open('time.out', 'r') as f:
        vals = []
        for line in f.readlines():
            vals.append(float(line))
        ##
        metric = stat.median(vals)
        result = {'unit' : ('cycles',),
            'desc' : ('Total',),
            'exps' : tuple([(v,) for v in vals]),
            'metric' :  metric}
    ##

#    r = re.search('.*Time.*',std)
#    m = []
#    if r:
#       m = re.split('\s+', r.group())
#    result = 'N/A'
#    if m and len(m) >= 7:
#       result = float(m[7])

    return result


