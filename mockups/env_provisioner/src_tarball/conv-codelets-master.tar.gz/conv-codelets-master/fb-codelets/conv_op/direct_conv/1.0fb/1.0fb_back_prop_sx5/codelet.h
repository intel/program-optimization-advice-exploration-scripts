#include <iostream>
#include <fstream>

#if defined(_OPENMP)
# include <omp.h>
#endif

#define VEC_LENGTH 16 /* Assuming max 512 bit SIMD length */

#define LARGE_SIZE 1
#define CONST_DECL 0

/*
#if LARGE_SIZE
// define B in main; others are constant
//#define B 128 //other choices: 1, 4, 8, 16, 32, 64, 256
#define H 7      // other choices: 14, 28, 56, 112, 224
#define W 7      // other choices: 14, 28, 56, 112, 224
#define R_CI 32 // other choices: 32, 64, 256
#define MH 4     // other choices: 8, 16, 32
#define MW 4     // other choices: 8, 16, 32
#define R_CO 32 // other choices: 32, 64, 256
#define R_KH 3   // other choices: 1, 7
#define R_KW 3   // other choices: 1, 7
#define R_K 4    // other choices: 8

#else // SMALL_SIZE is 64 smaller than LARGE_SIZE

#define B 16    // other choices: 1, 4, 8, 16, 32, 64, 256
#define H 7     // other choices: 14, 28, 56, 112, 224
#define W 7     // other choices: 14, 28, 56, 112, 224
#define R_CI 64 // other choices: 32, 64, 256
#define MH 4    // other choices: 8, 16, 32
#define MW 4    // other choices: 8, 16, 32
#define R_CO 64 // other choices: 32, 64, 256
#define R_KH 3  // other choices: 1, 7
#define R_KW 3  // other choices: 1, 7
#define R_K 4   // other choices: 8

#endif
*/

#if CONST_DECL
// int votes[B][H][W][R_CO][MH][MW];
typedef float votes_T /*[B]*/[H][W][R_CO][MH][MW];

// int poses[B][H*2+R_KH-2][W*2+R_KW-2][R_CI][MH][R_K];
// Fixed the padding on H and W
typedef float poses_T /*[B]*/[(H - 1) * 2 + R_KH][(W - 1) * 2 + R_KW][R_CI]
                             [MH][R_K];

// int weights[R_CI][R_CO][R_KH][R_KW][R_K][MW];
typedef float weights_T /*[R_CI]*/[R_CO][R_KH][R_KW][R_K][MW];
#else
typedef float votes_T /*[B]*/;
typedef float poses_T /*[B]*/;
typedef float weights_T /*[R_CI]*/;
#endif

class Param {
    int _B;     // other choices: 1, 4, 8, 16, 32, 64, 256
    int _H;     // other choices: 7, 14, 28, 56, 112, 224
    int _W;     // other choices: 7, 14, 28, 56, 112, 224
    int _R_CI; // other choices: 32, 64, 256
    int _MH;    // other choices: 4, 8, 16, 32
    int _MW;    // other choices: 4, 8, 16, 32
    int _R_CO; // other choices: 32, 64, 256
    int _R_KH;  // other choices: 1, 3, 7
    int _R_KW;  // other choices: 1, 3, 7
    int _R_K;   // other choices: 4, 8
  public:
    inline void getValues(int *pB, int *pH, int* pW, int *pR_CI, int *pMH, int *pMW, int *pR_CO, int* pR_KH, int* pR_KW, int* pR_K) const { 
      *pB = _B; 
      *pH = _H;
      *pW = _W;
      *pR_CI = _R_CI;
      *pMH = _MH;
      *pMW = _MW;
      *pR_CO = _R_CO;
      *pR_KH = _R_KH;
      *pR_KW = _R_KW;
      *pR_K = _R_K;
    }

    int sizeof_votes_T() {
      return /*[B]*/(_H)*(_W)*(_R_CO)*(_MH)*(_MW)*sizeof(float);
    }
    int sizeof_poses_T() {
      return /*[B]*/((_H - 1) * 2 + _R_KH)*((_W - 1) * 2 + _R_KW)*(_R_CI)* (_MH)*(_R_K)*sizeof(float);
    }
    int sizeof_weights_T() {
      return /*[R_CI]*/(_R_CO)*(_R_KH)*(_R_KW)*(_R_K)*(_MW)*sizeof(float);
    }
    int vote_size() {
      return _B * _H * _W * _R_CO * _MH * _MW;
    }
    int flops_per_vote() {
      return _R_KH * _R_KW * _R_CI * _R_K * 2;

    }
    bool read_argument(std::ifstream& infile, int& v) {
      char delimiter=':';
      infile >> v;
      char peek = infile.peek();
      if (peek == ':' || peek == '\n') {
        infile.ignore();
        return true;
      } else {
        return false;
      }
      // return true if correct delimiter; false if not
    }
    bool read_arguments(std::ifstream& infile) {
      if (!read_argument(infile, _B)) return false;
      if (!read_argument(infile, _H)) return false;
      if (!read_argument(infile, _W)) return false;
      if (!read_argument(infile, _R_CI)) return false;
      if (!read_argument(infile, _MH)) return false;
      if (!read_argument(infile, _MW)) return false;
      if (!read_argument(infile, _R_CO)) return false;
      if (!read_argument(infile, _R_KH)) return false;
      if (!read_argument(infile, _R_KW)) return false;
      if (!read_argument(infile, _R_K)) return false;
      return true;
    }
    friend std::ostream& operator<<(std::ostream& os, const Param& dt);
};

inline std::ostream& operator<<(std::ostream& os, const Param& dt) {
  os << dt._B << ":" << dt._H << ":" << dt._W << ":" << dt._R_CI << ":" << dt._MH << ":" << dt._MW << ":" 
    << dt._R_CO << ":" <<dt._R_KH << ":" << dt._R_KW << ":" << dt._R_K << std::endl;
  return os;
}

//void calc_capsule_simple(const int B, votes_T *votes, weights_T *weights, poses_T *poses);
void calc_capsule_simple(const Param& read_param, votes_T *votes, weights_T *weights, poses_T *poses);