#include <cctype>
#include <iomanip>
#include <iostream>
#include <fstream>
#include <random>
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
#include <string.h>

#include <omp.h>
#include "codelet.h"
#include "measure.h"


std::uniform_real_distribution<float> distribution(-1.0, 1.0);
unsigned seed = 1;

/*initialize the value with enough bits setting to 1, the power consumption may
 * be differnent if it is all 0 */
//void init_poses(const int B, poses_T *poses) {
void init_poses(const Param& read_param, poses_T *poses) {
  int B, H, W, R_CI, MH, MW, R_CO, R_KH, R_KW, R_K;
  read_param.getValues(&B, &H, &W, &R_CI, &MH, &MW, &R_CO, &R_KH, &R_KW, &R_K);
  
  // typedef float poses_T /*[B]*/[(H - 1) * 2 + R_KH][(W - 1) * 2 + R_KW][R_CI]
  //                        [MH][R_K];
  // so for poses[b][h][w][r_ci][m][r_k] we have the following strides
  int m_stride = R_K;
  int r_ci_stride = MH * m_stride;
  int w_stride = R_CI * r_ci_stride;
  int h_stride = ((W - 1) * 2 + R_KW) * w_stride;
  int b_stride = ((H - 1) * 2 + R_KH) * h_stride;

  for (int b = 0; b < B; b++) {
    for (int h = 0; h < (H - 1) * 2 + R_KH; h++) {
      for (int w = 0; w < (W - 1) * 2 + R_KW; w++) {
        for (int r_ci = 0; r_ci < R_CI; r_ci++) {
          for (int m = 0; m < MH; m++) {
            for (int r_k = 0; r_k < R_K; r_k++) {
              // for (int ci32 = 0; ci32 < 32; ci32++){
              static thread_local std::mt19937 generator(seed);
              //poses[b][h][w][r_ci][m][r_k] =
              poses[b*b_stride + h*h_stride + w*w_stride + r_ci*r_ci_stride + m*m_stride + r_k] =
                  distribution(generator) / R_CI / R_K;
              //}
            }
          }
        }
      }
    }
  }
}

/*initialize the value with enough bits setting to 1, the power consumption may
 * be differnent if it is all 0 */
void init_weights(const Param& read_param, weights_T *weights) {
  int B, H, W, R_CI, MH, MW, R_CO, R_KH, R_KW, R_K;
  read_param.getValues(&B, &H, &W, &R_CI, &MH, &MW, &R_CO, &R_KH, &R_KW, &R_K);
  // typedef float weights_T /*[R_CI]*/[R_CO][R_KH][R_KW][R_K][MW];
  // so for weights[r_ci][co][r_kh][r_kw][r_k][n] we have the following strides
  int r_k_stride = MW;
  int r_kw_stride = R_K*r_k_stride;
  int r_kh_stride = R_KW*r_kw_stride;
  int co_stride = R_KH*r_kh_stride;
  int r_ci_stride = R_CO*co_stride;

  for (int r_ci = 0; r_ci < R_CI; r_ci++) {
    for (int co = 0; co < R_CO; co++) {
      for (int r_kh = 0; r_kh < R_KH; r_kh++) {
        for (int r_kw = 0; r_kw < R_KW; r_kw++) {
          for (int r_k = 0; r_k < R_K; r_k++) {
            for (int n = 0; n < MW; n++) {
              // for (int ci32 = 0; ci32 < 32; ci32++){
              // for (int co32 = 0; co32 < 32; co32++){
              static thread_local std::mt19937 generator(seed);
              // weights[r_ci][co][r_kh][r_kw][r_k][n] = distribution(generator);
              weights[r_ci*r_ci_stride + co*co_stride + r_kh*r_kh_stride + r_kw*r_kw_stride + r_k*r_k_stride + n] = distribution(generator);
              //}
              //}
            }
          }
        }
      }
    }
  }
}

//void zero_votes(const int B, votes_T *votes) {
void zero_votes(const Param& read_param, votes_T *votes) {
  int B, H, W, R_CI, MH, MW, R_CO, R_KH, R_KW, R_K;
  read_param.getValues(&B, &H, &W, &R_CI, &MH, &MW, &R_CO, &R_KH, &R_KW, &R_K);
  // typedef float votes_T /*[B]*/[H][W][R_CO][MH][MW];
  // so for votes[b][h][w][co][m][n] we have the following strides
  int m_stride = MW;
  int co_stride = MH*m_stride;
  int w_stride = R_CO*co_stride;
  int h_stride = W*w_stride;
  int b_stride = H*h_stride;

  for (int b = 0; b < B; b++) {
    for (int h = 0; h < H; h++) {
      for (int w = 0; w < W; w++) {
        for (int co = 0; co < R_CO; co++) {
          for (int m = 0; m < MH; m++) {
            for (int n = 0; n < MW; n++) {
              //votes[b][h][w][co][m][n] = 0.0;
              votes[b*b_stride + h*h_stride + w*w_stride + co*co_stride + m*m_stride + n] = 0.0;
            }
          }
        }
      }
    }
  }
}

void parseCommandLine(const int argc, const char **argv, int &B) {
  for (int i = 1; i < argc; i++) {
    if (strcmp(argv[i], "-B") == 0) {
      if ((i + 1 < argc) && isdigit(*argv[i + 1])) {
        B = atoi(argv[i + 1]);
        i++;
      }
    }
    else if (strcmp(argv[i], "-help") == 0) {
      std::cout << "usage:  -B <batch size>" << std::endl;
      std::cout << "        by default batsch size is 128 and we run on the CPU"
                << std::endl;
      std::exit(0);
    }
  }
}
// The TimeInterval is a simple RAII class.
// Construct the timer at the point you want to start timing.
// Use the Elapsed() method to return time since construction.

class TimeInterval {
public:
  TimeInterval() : start_(std::chrono::steady_clock::now()) {}

  double Elapsed() {
    auto now = std::chrono::steady_clock::now();
    return std::chrono::duration_cast<Duration>(now - start_).count();
  }

private:
  using Duration = std::chrono::duration<double>;
  std::chrono::steady_clock::time_point start_;
};

int read_arguments (Param& param, int* repetitions)
{
  std::ifstream infile("codelet.data");
  if (infile.is_open()) {
    infile >> *repetitions;
    if (!param.read_arguments(infile)) {
      return -1;
    }
    infile.close();
    return 0;
  } else {
    return -1;
  }
}

int main(const int argc, const char **argv) {
  //int B = 128; // batchsize
  int B, H, W, R_CI, MH, MW, R_CO, R_KH, R_KW, R_K;
  parseCommandLine(argc, argv, B);
  int iters;
  Param read_param;

  if (read_arguments (read_param, &iters) == -1)
  {
    std::cout << "Failed to load codelet.data!" << std::endl;
    return -1;
  }
  read_param.getValues(&B, &H, &W, &R_CI, &MH, &MW, &R_CO, &R_KH, &R_KW, &R_K);
  std::cout << B << ":" << H << ":" << W << ":" << R_CI << ":" << MH << ":" << MW << ":" 
    << R_CO << ":" <<R_KH << ":" << R_KW << ":" << R_K << std::endl;
  std::cout << read_param << std::endl;

  //votes_T *votes = (votes_T *)malloc(B * sizeof(votes_T));
  votes_T *votes = (votes_T *)malloc(B * read_param.sizeof_votes_T());
  //poses_T *poses = (poses_T *)malloc(B * sizeof(poses_T));
  poses_T *poses = (poses_T *)malloc(B * read_param.sizeof_poses_T());
  weights_T *weights =
      (weights_T *)malloc(R_CI * read_param.sizeof_weights_T());
      //(weights_T *)malloc(R_CI * sizeof(weights_T));

  //init_poses(B, poses);
  init_poses(read_param, poses);
  init_weights(read_param, weights);

  struct fnInfo {
    //void (*f)(const int B, votes_T *votes, weights_T *weights, poses_T *poses);
    void (*f)(const Param& read_param, votes_T *votes, weights_T *weights, poses_T *poses);
    const char *name;
    double sum;
    double elapsed_time;
  };

  struct fnInfo fnTable[] = {
      {calc_capsule_simple, "calc_capsule_simple", 0.0, 0.0},
//      {calc_capsule_parallel_simple, "calc_capsule_parallel_simple", 0.0, 0.0},
      {0, 0}};
  const int fn_count = (sizeof(fnTable) / sizeof(struct fnInfo)) - 1;

  // compute answer
  for (int i = 0; i < fn_count; i++) {
    struct fnInfo *fp = &fnTable[i];
    std::cout << "starting " << fp->name << std::endl;
    //zero_votes(B, votes);
    zero_votes(read_param, votes);
    //(*fp->f)(B, votes, weights, poses);
    (*fp->f)(read_param, votes, weights, poses);
    std::cout << "  finish warm up" << std::endl;

    //zero_votes(B, votes);
    zero_votes(read_param, votes);
    TimeInterval t_par;


    measure_init_();
    measure_sec_spin_(15);
    measure_start_();
    // reference execute time on ancodskx1020:
    // starting calc_capsule_simple
    // finish warm up
    // finish timing
    // vote size(3211264) flops per vote(2304) total_flops(7.39875e+09)
    // GFlops:  3.1548454  time:  2345.2028ms  calc_capsule_simple
    for (i = 0; i < iters; ++i) {
      //(*fp->f)(B, votes, weights, poses);
      (*fp->f)(read_param, votes, weights, poses);
    }
    measure_stop_();


    fp->elapsed_time = t_par.Elapsed();
    std::cout << "  finish timing" << std::endl;

  }

  const int vote_size = read_param.vote_size();
  const int flops_per_vote = read_param.flops_per_vote();
  const double total_flops =
      static_cast<double>(vote_size) * static_cast<double>(flops_per_vote);

  std::cout << "vote size(" << vote_size << ") flops per vote("
            << flops_per_vote << ") total_flops(" << total_flops << ")"
            << std::endl;

  for (int i = 0; i < fn_count; i++) {
    struct fnInfo *fp = &fnTable[i];
    std::cout << std::showpoint << "  GFlops: " << std::setprecision(8)
              << std::setw(10) << ((total_flops / 1.0e+9) / fp->elapsed_time)
              << "  time: " << std::setprecision(8) << std::setw(10)
              << fp->elapsed_time * 1000.0 << "ms"
              << "  " << fp->name << std::endl;
  }

  free(votes);
  free(poses);
  free(weights);

  return 0;
}